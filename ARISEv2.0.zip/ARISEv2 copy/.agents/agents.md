# GLOBAL MULTI-MODE DIRECTIVE: STATE & ARCHITECTURE MACHINE
# AAWMP v4.0 | Fixed Edition
# Fixes applied: startup gate conflict, Section C read direction, IDE hijack removed

---

## 1. MANDATORY STARTUP GATE

```
Session starts
    │
    ├─► Does .agents/scratchpad.md EXIST?
    │       │
    │       ├── NO  ──► This is a brand new project. Skip to Phase 1.
    │       │           Do NOT read a file that doesn't exist.
    │       │
    │       └── YES ──► Read Section C (last 3 most recent entries only).
    │                   Then check: is Section B populated?
    │                       YES ──► Proceed to Phase 2.
    │                       NO  ──► Proceed to Phase 1.
```

- **Context Locking:** You cannot modify any application file until you have
  appended a valid single-line [PRE: HH:MM] token to Section A.
- **No blind scanning:** If unsure about codebase state, read Section B before
  running any directory scan. Never scan what Section B already maps.

---

## 2. THE TOKEN-SAVING PHASE LIFE CYCLE

### PHASE 1: SKELETON BUILD (Prompts 1-2)
- Scratchpad does not exist yet or Section B is empty.
- Trust short-term conversation context fully. No scratchpad reads.
- Focus exclusively on structural component creation.
- AT THE END OF PROMPT 2: Execute one comprehensive write to Section B,
  mapping all created file paths with a description under 10 words each.
- This snapshot is the most valuable action of the entire session.

### PHASE 2: FEATURE DEVELOPMENT (Prompts 3-15)
- Section B is now populated. It is the absolute truth of the filesystem.
- If a target file path is registered in Section B → edit it directly.
  Do NOT view parent directories to confirm existence.
- If a path is MISSING from Section B:
  → Scan only its immediate parent folder.
  → Perform the edit.
  → Append the new path to Section B immediately.
- Write Section A [PRE] before editing. Write [POST] after. One line each.
- Write one line to Section C after every real task completes.

### PHASE 3: DEEP CONTEXT REFRESH (Prompts 15+)
- Context window is filling. Conversation memory may be truncated.
- Read only the 3 MOST RECENT entries of Section C (~50 tokens).
  (Section C is newest-on-top. The 3 most recent = the first 3 lines.)
- If memory remains unclear after reading: ask the user ONE direct question.
  Do NOT re-scan the codebase. Do NOT read the full scratchpad.
- If output accuracy is dropping: trigger a context reset immediately.
  New session + loaded scratchpad > bloated continuing session.

---

## 3. THE 7 NON-NEGOTIABLE COGNITIVE LAWS

- **LAW 1:** Section B IS the filesystem. Trust it. Never verify it with a scan.
- **LAW 2:** Read only what you need. Section C for timeline. Section B for paths.
  Section D for errors. Never read the full scratchpad.
- **LAW 3:** Every log entry (PRE, POST, RETRO, ERROR, FIX, ARCHIVE) must
  occupy exactly ONE LINE. No multi-line blocks. No sub-bullets.
- **LAW 4:** Append-only ledger. Never delete, rewrite, or mutate existing lines.
- **LAW 5:** Manage bloat. Section A exceeds 10 entries → move oldest 8 to
  archive.md immediately. Total scratchpad must never exceed 50 lines.
- **LAW 6:** Lifecycle phase dictates primary memory source.
  Phase 1 → conversation. Phase 2 → Section B. Phase 3 → Section C.
- **LAW 7:** The scratchpad is the canonical save file. A fresh session
  loaded from a clean scratchpad is superior to a bloated context thread.

---

## 4. MULTI-AGENT BOUNDARY OPERATIONS

### Intent Broadcasting (Conflict Prevention)
```
Before editing any file:
    │
    ├─► Read Section A (latest entries only).
    │
    ├─► Is there a [PRE] entry for this file logged < 5 minutes ago?
    │       YES ──► Pause execution. Wait or pick an unallocated file.
    │       NO  ──► Safe to proceed. Write your own [PRE] entry.
    │
    └─► After task: write [POST] entry. Signal to other agents you are done.
```

### Scope Isolation (Role Enforcement)
```
Task received
    │
    ├─► Read your assigned role file: .agents/agents/[your-role].md
    │
    ├─► Is this task within your defined domain boundary?
    │       YES ──► Proceed.
    │       NO  ──► Abort immediately. Refer task to Orchestrator.
    │               Write [SCOPE-VIOLATION: HH:MM] to Section D.
```

### Agent Role Map
```
code-agent        → feature files, component files. Writes A + C.
debug-agent       → error logs, stack traces, failing tests. Writes D.
plan-agent        → implementation_plan.md only. Read-only scratchpad.
review-agent      → entire codebase, read-only. Writes nothing.
orchestrator      → reads B + C. Decomposes tasks. Writes C only.
```

---

## 5. QUICK LOOKUP TABLE

| Situation                  | Section | Action                        |
|----------------------------|---------|-------------------------------|
| Brand new project          | —       | Skip scratchpad, go Phase 1   |
| Session start (existing)   | C       | Read last 3 most recent lines |
| Starting a real task       | A       | Write PRE (1 line)            |
| Finishing a real task      | A + C   | Write POST + history (1 line) |
| Trivial 1-line change      | A       | Write POST only               |
| Read-only / question task  | —       | Skip all sections             |
| Need to find a file        | B       | Read inventory first          |
| New file created           | B       | Append 1 line                 |
| Context lost mid-session   | C       | Read last 5 most recent lines |
| Something broke            | D       | Follow error tree             |
| Section A > 10 entries     | —       | Archive oldest 8 to archive.md|
| Another agent editing file | A       | Check PRE entries, wait 5 min |
| Task outside your scope    | D       | Log violation, refer to Orch. |
