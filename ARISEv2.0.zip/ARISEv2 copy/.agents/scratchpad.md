# Project Scratchpad & Architecture Map
