#!/usr/bin/env python3
"""
ARISE Dashboard v3.0 - "Summon Every Hidden Exposure."
Complete rewrite with proper data ingestion, caching, and state management
Fixes: Target switching, port data, multi-scan isolation, real-time updates
"""

import os
import json
import glob
import re
import subprocess
import logging
from datetime import datetime
from pathlib import Path
from functools import lru_cache
from flask import Flask, render_template, jsonify, request
from flask_cors import CORS
import threading
import time
from logging.handlers import RotatingFileHandler

# Load .env (API keys, Slack webhook, AI settings) before reading any env vars.
try:
    from dotenv import load_dotenv
    load_dotenv(os.path.join(os.path.dirname(os.path.abspath(__file__)), '.env'))
except Exception:
    pass

app = Flask(__name__)
CORS(app)

# ===========================================================================
# CONFIGURATION
# ===========================================================================

BASE_SCAN_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'scans')
CACHE_TIMEOUT = 5  # seconds - refresh cache every 5 seconds
CURRENT_TARGET = {}  # Track per-session target
_SCAN_CACHE = {}
_SCAN_INDEX_CACHE = {'timestamp': 0, 'scans': []}
PORT_MAPPINGS = {
    22: 'SSH', 21: 'FTP', 25: 'SMTP', 53: 'DNS', 80: 'HTTP', 110: 'POP3',
    143: 'IMAP', 389: 'LDAP', 443: 'HTTPS', 445: 'SMB', 587: 'SMTP',
    1433: 'MSSQL', 3306: 'MySQL', 3389: 'RDP', 5432: 'PostgreSQL',
    5984: 'CouchDB', 6379: 'Redis', 8080: 'HTTP-Alt', 8443: 'HTTPS-Alt',
    9200: 'Elasticsearch', 27017: 'MongoDB'
}
SEVERITY_WEIGHTS = {'critical': 40, 'high': 20, 'medium': 8, 'low': 2, 'info': 0}

# ---------------------------------------------------------------------------
# AI Security Analyst — reads assembled scan context, produces an executive
# analysis, and optionally pushes it to Slack. The model is Claude (Anthropic
# SDK); the Slack push uses an Incoming Webhook. Both are configured by env var
# and degrade gracefully when unset.
# ---------------------------------------------------------------------------
AI_MODEL = os.environ.get('ARISE_AI_MODEL', 'claude-opus-4-8')
SLACK_WEBHOOK_URL = os.environ.get('SLACK_WEBHOOK_URL', '')

# Persisted global AI settings (provider / model / auto-Slack), editable from the
# dashboard's Settings panel. Defaults come from .env; the file overrides them.
SETTINGS_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'arise_settings.json')
AI_PROVIDER_ENV = os.environ.get('ARISE_AI_PROVIDER', '').strip()
AUTO_SLACK_DEFAULT = os.environ.get('ARISE_AUTO_SLACK', 'true').strip().lower() in ('1', 'true', 'yes', 'on')
AI_WATCH_INTERVAL = int(os.environ.get('ARISE_AI_WATCH_INTERVAL', '20'))  # seconds

# Ports grouped by blast radius: unauthenticated data stores and remote-shell
# services are tier-1; management protocols and legacy services are tier-2.
PORT_RISK_TIER1 = {6379, 9200, 27017, 5984, 11211}       # Redis, Elastic, Mongo, Couch, Memcached
PORT_RISK_TIER2 = {3306, 5432, 1433}                      # MySQL, Postgres, MSSQL
PORT_RISK_TIER3 = {3389, 22, 23, 445, 21, 25, 110, 143}  # RDP, SSH, Telnet, SMB, FTP, SMTP, POP, IMAP
SENSITIVE_PORTS = PORT_RISK_TIER1 | PORT_RISK_TIER2 | PORT_RISK_TIER3

# Cloud tab taxonomy — the Cloud dashboard shows ONLY these. Anything the
# pipeline classified into an app/API bucket (XSS, SQLi, SSRF, IDOR, JWT, …)
# never reaches here; the whitelist is the hard boundary between the Cloud tab
# and the Vulns/API tabs.
CLOUD_SECURITY_CATEGORIES = {
    'public_cloud_storage', 'public_kubernetes_api', 'metadata_service_exposure',
    'leaked_cloud_credentials', 'terraform_state_exposed', 'public_elasticsearch',
    'public_cicd', 'public_redis_mongo', 'grafana_prometheus_exposed',
    'cdn_origin_bypass', 'debug_endpoint',
}
# Control-gap posture findings — cloud/infra hygiene, shown in a separate group.
CLOUD_POSTURE_CATEGORIES = {'missing_waf', 'missing_email_auth', 'information_disclosure'}
CLOUD_ALL_CATEGORIES = CLOUD_SECURITY_CATEGORIES | CLOUD_POSTURE_CATEGORIES

# Provider fingerprints for cloud recon — maps httpx `tech`/CDN strings and IP
# owners to a canonical provider so the recon panel can inventory the estate.
CLOUD_PROVIDER_TECH = {
    'aws': ['amazon web services', 'amazon cloudfront', 'amazon s3', 'amazon elb',
            'aws', 'cloudfront', 's3', 'elastic load balancing', 'awselb'],
    'gcp': ['google cloud', 'google-cloud', 'gcs', 'google storage', 'firebase',
            'app engine', 'cloud run', 'googleusercontent'],
    'azure': ['azure', 'microsoft azure', 'azure blob', 'azure cdn', 'windows-azure'],
    'cloudflare': ['cloudflare'],
    'fastly': ['fastly'],
    'akamai': ['akamai'],
}


def setup_logging():
    """Configure a central rotating log for the dashboard."""
    log_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'logs')
    os.makedirs(log_dir, exist_ok=True)

    logger = logging.getLogger('dashboard')
    logger.setLevel(logging.INFO)
    logger.propagate = False

    if not logger.handlers:
        formatter = logging.Formatter('%(asctime)s %(levelname)s %(name)s %(message)s')

        file_handler = RotatingFileHandler(
            os.path.join(log_dir, 'dashboard.log'),
            maxBytes=1_000_000,
            backupCount=5
        )
        file_handler.setFormatter(formatter)
        logger.addHandler(file_handler)

        stream_handler = logging.StreamHandler()
        stream_handler.setFormatter(formatter)
        logger.addHandler(stream_handler)

    return logger


logger = setup_logging()


def load_json_file(filepath):
    """Load a JSON file safely and log any parse failures."""
    if not filepath or not os.path.exists(filepath):
        return {}
    try:
        with open(filepath, 'r') as handle:
            return json.load(handle)
    except Exception as exc:
        logger.error("Failed to load JSON %s: %s", filepath, exc)
        return {}


def parse_scan_time(value):
    """Parse pipeline timestamps, falling back cleanly when older data is incomplete."""
    if not value:
        return datetime.min
    try:
        return datetime.fromisoformat(str(value).replace('Z', '+00:00'))
    except Exception:
        return datetime.min


def scan_time_key(value, fallback=0):
    try:
        parsed = parse_scan_time(value)
        return parsed.timestamp() if parsed != datetime.min else fallback
    except Exception:
        return fallback

# ===========================================================================
# CORE DATA PIPELINE
# ===========================================================================

class ScanDataPipeline:
    """Manages data ingestion from easm-pipeline outputs"""
    
    def __init__(self, scan_dir):
        self.scan_dir = scan_dir
        self.manifest_file = os.path.join(scan_dir, 'manifest.json')
        self._cache = {}
        self._cache_time = {}
    
    def load_manifest(self):
        """Load and parse manifest.json"""
        if not os.path.exists(self.manifest_file):
            logger.info("Manifest missing: %s", self.manifest_file)
            return {'pipeline_info': {}, 'statistics': {}, 'hosts': {}}
        
        try:
            with open(self.manifest_file, 'r') as f:
                return json.load(f)
        except Exception as exc:
            logger.error("Failed to parse manifest %s: %s", self.manifest_file, exc)
            return {'pipeline_info': {}, 'statistics': {}, 'hosts': {}}
    
    def load_port_data(self):
        """Extract port data from naabu output"""
        sources = [
            os.path.join(self.scan_dir, '04_http_discovery/all_ports_full.json'),
            os.path.join(self.scan_dir, '04_http_discovery/all_ports_list.txt'),
            os.path.join(self.scan_dir, '14_port_scan/all_ports.jsonl'),
            os.path.join(self.scan_dir, '04_http_discovery/all_ports.json'),
        ]
        ports_data = {}

        for source in sources:
            if not os.path.exists(source):
                continue

            try:
                with open(source, 'r', errors='ignore') as handle:
                    for line in handle:
                        line = line.strip()
                        if not line:
                            continue

                        host = None
                        port = None

                        if source.endswith('.txt'):
                            parts = line.split(':')
                            if len(parts) == 2 and parts[1].isdigit():
                                host, port = parts[0], int(parts[1])
                        else:
                            try:
                                entry = json.loads(line)
                            except Exception:
                                continue
                            host = entry.get('host') or entry.get('ip')
                            port = entry.get('port')

                        if host and port:
                            ports_data.setdefault(host, [])
                            if port not in ports_data[host]:
                                ports_data[host].append(int(port))
            except Exception as exc:
                logger.error("Failed to read port source %s: %s", source, exc)

        for host in ports_data:
            ports_data[host] = sorted(set(ports_data[host]))

        return ports_data

    def get_port_scan_status(self):
        """Detect whether the port scan succeeded, crashed, or is missing."""
        manifest = self.load_manifest()
        status_from_manifest = manifest.get('statistics', {}).get('port_scan_status')
        if status_from_manifest:
            return status_from_manifest

        jsonl = os.path.join(self.scan_dir, '14_port_scan/all_ports.jsonl')
        stderr = os.path.join(self.scan_dir, '14_port_scan/naabu.stderr')
        scan_dir_exists = os.path.isdir(os.path.join(self.scan_dir, '14_port_scan'))

        if not scan_dir_exists:
            return 'missing'

        has_results = os.path.exists(jsonl) and os.path.getsize(jsonl) > 0
        if has_results:
            return 'ok'

        if os.path.exists(stderr):
            try:
                with open(stderr, 'r', errors='ignore') as f:
                    head = f.read(4096)
                if 'pthread_create failed' in head or 'SIGABRT' in head or 'runtime/cgo' in head:
                    return 'crashed'
            except Exception:
                pass

        return 'no_open_ports'
    
    def load_service_data(self):
        """Load nmap service fingerprinting results"""
        services_json = os.path.join(self.scan_dir, '07_service_fingerprint/services.json')
        services = {}
        
        if os.path.exists(services_json):
            try:
                with open(services_json, 'r') as f:
                    data = json.load(f)
                    if isinstance(data, list):
                        for svc in data:
                            host = svc.get('host')
                            if host:
                                if host not in services:
                                    services[host] = []
                                services[host].append(svc)
            except Exception as exc:
                logger.error("Failed to read service data %s: %s", services_json, exc)
        
        return services
    
    def load_vulnerabilities(self):
        """Load vulnerabilities from all sources"""
        vulns = []
        
        # Nuclei results
        nuclei_dirs = [
            os.path.join(self.scan_dir, '12_nuclei_scanning'),
            os.path.join(self.scan_dir, 'nuclei_scanning')
        ]
        
        for nuclei_dir in nuclei_dirs:
            if os.path.exists(nuclei_dir):
                for root, dirs, files in os.walk(nuclei_dir):
                    for file in files:
                        if file.endswith(('.json', '.txt', '.jsonl')):
                            filepath = os.path.join(root, file)
                            try:
                                with open(filepath, 'r') as f:
                                    for line in f:
                                        try:
                                            entry = json.loads(line.strip())
                                            vuln = self._parse_nuclei_result(entry)
                                            if vuln:
                                                vulns.append(vuln)
                                        except Exception:
                                            continue
                            except Exception as exc:
                                logger.error("Failed to read nuclei file %s: %s", filepath, exc)
        
        # XSS results
        xss_file = os.path.join(self.scan_dir, '13_xss_testing/xss_results.txt')
        if os.path.exists(xss_file):
            try:
                with open(xss_file, 'r') as f:
                    for line in f:
                        line = line.strip()
                        if line:
                            vulns.append({
                                'source': 'XSS Testing',
                                'template': 'XSS Vulnerability',
                                'severity': 'high',
                                'host': 'Unknown',
                                'url': line,
                                'impact': 'Client-side code injection',
                                'remediation': 'Input validation and output encoding'
                            })
            except Exception as exc:
                logger.error("Failed to read XSS results %s: %s", xss_file, exc)
        
        # Secret scan results
        secrets_file = os.path.join(self.scan_dir, '10_secret_scanning/secrets.jsonl')
        if os.path.exists(secrets_file):
            # Load TSV index to map filenames to URLs
            index_tsv = os.path.join(self.scan_dir, '09_crawling/js_downloads/index.tsv')
            js_url_map = {}
            if os.path.exists(index_tsv):
                try:
                    with open(index_tsv, 'r') as f:
                        for line in f:
                            parts = line.strip().split('\t')
                            if len(parts) == 2:
                                js_url_map[parts[1]] = parts[0]
                except Exception as exc:
                    logger.error("Failed to read js index.tsv %s: %s", index_tsv, exc)

            try:
                with open(secrets_file, 'r') as f:
                    for line in f:
                        try:
                            entry = json.loads(line.strip())
                            
                            # Parse trufflehog structure
                            detector_name = entry.get('DetectorName', 'Credential')
                            raw_secret = entry.get('Redacted', '')
                            if not raw_secret:
                                raw_secret = entry.get('Raw', '')
                                
                            file_path = entry.get('SourceMetadata', {}).get('Data', {}).get('Filesystem', {}).get('file', '')
                            filename = os.path.basename(file_path)
                            
                            # Skip the index file itself as its MD5 hashes cause false positives
                            if filename == 'index.tsv':
                                continue
                                
                            url = js_url_map.get(filename, filename)
                            
                            # Extract host from URL
                            host = 'Unknown'
                            if url.startswith('http'):
                                try:
                                    host = url.split('//')[1].split('/')[0]
                                except Exception:
                                    pass
                                    
                            impact = f"Exposed {detector_name}"
                            if raw_secret:
                                impact += f" (Redacted: {raw_secret[:20]}...)"

                            vulns.append({
                                'source': 'Secret Scan',
                                'template': f'{detector_name} Key',
                                'severity': 'critical',
                                'host': host,
                                'url': url,
                                'impact': impact,
                                'remediation': 'Rotate credential immediately and review access logs'
                            })
                        except Exception as exc:
                            logger.error("Failed to parse secret entry: %s", exc)
                            continue
            except Exception as exc:
                logger.error("Failed to read secrets %s: %s", secrets_file, exc)
        # SQL injection results
        sqli_file = os.path.join(self.scan_dir, '15_sqli_testing/sqli_results.jsonl')
        if os.path.exists(sqli_file):
            try:
                with open(sqli_file, 'r') as f:
                    for line in f:
                        try:
                            entry = json.loads(line.strip())
                            confidence = entry.get('confidence', 'medium')
                            sqli_type = entry.get('type', 'unknown')
                            param = entry.get('parameter', 'unknown')
                            waf = entry.get('waf_vendor', '')
                            detection_pass = entry.get('detection_pass', 'baseline')
                            severity_map = {'high': 'critical', 'medium': 'high', 'low': 'medium'}
                            severity = severity_map.get(confidence, 'high')
                            waf_note = f' [behind {waf}]' if waf else ''
                            pass_note = f' via {detection_pass}' if detection_pass != 'baseline' else ''
                            vulns.append({
                                'source': 'SQLi Testing',
                                'template': f'SQL Injection ({sqli_type})',
                                'severity': severity,
                                'host': entry.get('host', 'Unknown'),
                                'url': entry.get('url', ''),
                                'impact': f'SQLi on param: {param} (type: {sqli_type}, confidence: {confidence}{waf_note}{pass_note})',
                                'remediation': 'Use parameterized queries / prepared statements; never concatenate user input into SQL',
                                'confidence': confidence,
                            })
                        except Exception:
                            continue
            except Exception as exc:
                logger.error("Failed to read SQLi results %s: %s", sqli_file, exc)

        # LFI / parameter fuzzing results
        lfi_file = os.path.join(self.scan_dir, '11_param_fuzzing/lfi_results.json')
        if os.path.exists(lfi_file):
            try:
                with open(lfi_file, 'r') as f:
                    lfi_results = json.load(f)
                for entry in lfi_results:
                    fuzz_url = entry.get('url', '')
                    host = 'Unknown'
                    if fuzz_url.startswith('http'):
                        try:
                            host = fuzz_url.split('//')[1].split('/')[0].split(':')[0]
                        except Exception:
                            pass
                    payload = entry.get('input', {}).get('FUZZ', '')
                    vulns.append({
                        'source': 'Param Fuzzing',
                        'template': 'Local File Inclusion (LFI)',
                        'severity': 'critical',
                        'host': host,
                        'url': fuzz_url,
                        'impact': f'LFI confirmed with payload: {payload}',
                        'remediation': 'Sanitize file path parameters; use allowlists instead of direct file access'
                    })
            except Exception as exc:
                logger.error("Failed to read LFI results %s: %s", lfi_file, exc)

        # Cloud attack surface exposure findings (weighted model)
        cloud_file = os.path.join(self.scan_dir, '17_cloud_exposure/cloud_findings.jsonl')
        if os.path.exists(cloud_file):
            try:
                with open(cloud_file, 'r') as f:
                    for line in f:
                        line = line.strip()
                        if not line:
                            continue
                        try:
                            entry = json.loads(line)
                        except Exception:
                            continue
                        label = entry.get('category_label', entry.get('cloud_category', 'Cloud Exposure'))
                        vulns.append({
                            'source': 'Cloud Exposure',
                            'template': label,
                            'severity': entry.get('severity', 'info'),
                            'host': entry.get('host', 'Unknown'),
                            'url': entry.get('url', ''),
                            'impact': entry.get('evidence', ''),
                            'remediation': entry.get('remediation', ''),
                            'cloud_category': entry.get('cloud_category'),
                            'base_weight': entry.get('base_weight'),
                            'exploitability': entry.get('exploitability'),
                            'exposure': entry.get('exposure'),
                            'exposure_note': entry.get('exposure_note'),
                            'weighted_score': entry.get('weighted_score'),
                            'detection_tool': entry.get('tool'),
                        })
            except Exception as exc:
                logger.error("Failed to read cloud findings %s: %s", cloud_file, exc)

        # Extended verification findings (Module 19) — dedicated safe-mode
        # scanners that confirm SSRF/CRLF/JWT/SSTI/GraphQL/smuggling.
        ext_file = os.path.join(self.scan_dir, '19_extended_checks/extended_findings.jsonl')
        if os.path.exists(ext_file):
            try:
                with open(ext_file, 'r', errors='ignore') as f:
                    for line in f:
                        line = line.strip()
                        if not line:
                            continue
                        try:
                            entry = json.loads(line)
                        except Exception:
                            continue
                        vulns.append({
                            'source': 'Extended Verification',
                            'template': entry.get('template', 'Extended finding'),
                            'severity': entry.get('severity', 'info'),
                            'host': entry.get('host', 'Unknown'),
                            'url': entry.get('url', ''),
                            'impact': entry.get('evidence', ''),
                            'remediation': entry.get('remediation', ''),
                            'check': entry.get('check'),
                            'detection_tool': entry.get('tool'),
                            'confidence': entry.get('confidence'),
                            'verification': entry.get('verification'),
                            'parameter': entry.get('parameter', ''),
                            'safe_mode': entry.get('safe_mode', True),
                        })
            except Exception as exc:
                logger.error("Failed to read extended findings %s: %s", ext_file, exc)

        # Deduplicate vulnerabilities to prevent double publishing
        unique_vulns = []
        seen = set()
        for v in vulns:
            # Create a unique key for the vulnerability based on core attributes
            key = (v.get('source'), v.get('template'), v.get('host'), v.get('url'), v.get('impact'))
            if key not in seen:
                seen.add(key)
                unique_vulns.append(v)
        
        return unique_vulns
    
    def _parse_nuclei_result(self, data):
        """Parse nuclei JSON output"""
        try:
            info = data.get('info', {})
            severity = info.get('severity', 'info').lower()
            return {
                'source': 'Nuclei',
                'template': info.get('name', 'Unknown'),
                'template_id': data.get('template-id', ''),
                'severity': severity,
                'host': data.get('host', 'Unknown'),
                'url': data.get('matched-at', data.get('url', '')),
                'impact': info.get('impact', ''),
                'remediation': info.get('remediation', ''),
                'cve_id': info.get('classification', {}).get('cve-id'),
                'cwe_id': info.get('classification', {}).get('cwe-id', [])
            }
        except Exception as exc:
            logger.error("Failed to parse nuclei result: %s", exc)
            return None
    
    def load_http_status(self):
        """Backfill http_status from httpx output when manifest is missing it."""
        http_file = os.path.join(self.scan_dir, '04_http_discovery/http_confirmed.json')
        result = {}
        if not os.path.exists(http_file):
            return result
        try:
            with open(http_file, 'r', errors='ignore') as f:
                for line in f:
                    try:
                        entry = json.loads(line.strip())
                        host = entry.get('input') or entry.get('host')
                        status = entry.get('status_code')
                        if host and status:
                            result[host] = int(status)
                    except Exception:
                        continue
        except Exception as exc:
            logger.error("Failed to read http_confirmed.json: %s", exc)
        return result

    def aggregate_host_data(self, manifest, ports_data, services, vulns):
        """Merge all data sources for each host"""
        hosts = {}

        for host, host_data in manifest.get('hosts', {}).items():
            hosts[host] = dict(host_data)

        for host, ports in ports_data.items():
            if host not in hosts:
                hosts[host] = {}
            hosts[host]['ports_open'] = sorted(set(ports))

        for host, svc_list in services.items():
            if host not in hosts:
                hosts[host] = {}
            hosts[host]['services'] = svc_list

        # Backfill http_status from httpx output for scans where the manifest is missing it
        http_status_map = self.load_http_status()
        for host, status in http_status_map.items():
            if host in hosts and not hosts[host].get('http_status'):
                hosts[host]['http_status'] = status
                hosts[host]['has_webapp'] = True

        # Compute per-host risk scores
        compute_risk_scores(hosts, vulns)

        return hosts


# ===========================================================================
# RISK SCORING ENGINE
# ===========================================================================

def compute_host_risk(host, host_data, host_vulns):
    """Compute a 0-100 host risk score across six weighted domains.

    Domains (raw caps; total clamped to 100):
      Vulnerability Exposure  35 — confirmed CVEs, nuclei findings, XSS
      Credential / Secret     25 — leaked keys, tokens, passwords in JS/repos
      Infrastructure Posture  20 — exposed ports, missing WAF, weak headers, cookies
      SSL / Domain Integrity  10 — dangling certs, missing SSL
      Attack Surface Breadth  10 — port count, service diversity, no-CDN exposure
      Cloud Exposure          40 — weighted cloud findings (base x exploitability x exposure)

    The cloud domain is additive and can drive a single host to critical on its
    own (e.g. a public bucket or leaked cloud credential), reflecting the blast
    radius of cloud-native exposures.
    """
    has_http = bool(host_data.get('http_status'))
    waf_vendor = (host_data.get('waf_vendor') or '').lower()
    has_waf = waf_vendor not in ('none', '')
    open_ports = set(int(p) for p in host_data.get('ports_open', []))
    header_score = host_data.get('security_header_score', 0)

    # ── Domain 1: Vulnerability Exposure (0-35) ──
    vuln_domain = 0.0
    non_secret_vulns = [v for v in host_vulns if v.get('source') not in ('Secret Scan', 'SQLi Testing', 'Cloud Exposure')]
    sqli_hits = [v for v in host_vulns if v.get('source') == 'SQLi Testing']
    if non_secret_vulns or sqli_hits:
        raw = 0
        for v in non_secret_vulns:
            raw += SEVERITY_WEIGHTS.get(v.get('severity', 'info'), 0)
        # Confirmed SQLi = direct DB access; weight higher than generic nuclei finding
        for v in sqli_hits:
            confidence = v.get('confidence', 'medium')
            raw += 50 if confidence == 'high' else 30
        vuln_domain = min(raw / 80.0, 1.0) * 35

    # ── Domain 2: Credential / Secret / Data Access Exposure (0-25) ──
    secret_domain = 0.0
    secrets = [v for v in host_vulns if v.get('source') == 'Secret Scan']
    lfi_hits = [v for v in host_vulns if v.get('source') == 'Param Fuzzing']
    if secrets or lfi_hits or sqli_hits:
        secret_raw = 0.0
        # First secret is catastrophic (70%), each additional adds diminishing impact
        if secrets:
            secret_raw = 0.7 + min(len(secrets) - 1, 5) * 0.06
        # LFI = file read primitive, nearly as severe
        if lfi_hits:
            secret_raw = max(secret_raw, 0.5) + min(len(lfi_hits), 3) * 0.1
        # SQLi = potential full DB dump; high-confidence SQLi is near-secret severity
        if sqli_hits:
            high_conf = sum(1 for v in sqli_hits if v.get('confidence') == 'high')
            med_conf = len(sqli_hits) - high_conf
            sqli_raw = high_conf * 0.6 + med_conf * 0.3
            secret_raw = max(secret_raw, 0.0) + min(sqli_raw, 0.8)
        secret_domain = min(secret_raw, 1.0) * 25

    # ── Domain 3: Infrastructure Posture (0-20) ──
    posture_domain = 0.0
    posture_deductions = 0.0

    # Exposed data stores (tier 1) — direct unauthenticated access risk
    tier1_exposed = open_ports & PORT_RISK_TIER1
    posture_deductions += len(tier1_exposed) * 0.20

    # Exposed databases (tier 2) — auth-gated but still shouldn't be public
    tier2_exposed = open_ports & PORT_RISK_TIER2
    posture_deductions += len(tier2_exposed) * 0.12

    # Exposed management/legacy (tier 3)
    tier3_exposed = open_ports & PORT_RISK_TIER3
    posture_deductions += len(tier3_exposed) * 0.06

    # Missing WAF on an internet-facing web app
    if has_http and not has_waf:
        posture_deductions += 0.15

    # Weak security headers (scale: 0/6 = full penalty, 6/6 = none)
    if has_http:
        posture_deductions += (1.0 - header_score / 6.0) * 0.15

    # Cookie security issues
    cookie_issues = host_data.get('cookie_issues', [])
    if cookie_issues:
        posture_deductions += min(len(cookie_issues), 3) * 0.05

    posture_domain = min(posture_deductions, 1.0) * 20

    # ── Domain 4: SSL / Domain Integrity (0-10) ──
    ssl_domain = 0.0
    ssl_checked = host_data.get('ssl_checked', False)

    if ssl_checked:
        if host_data.get('ssl_dangling', False):
            # Dangling domain — full subdomain takeover risk
            ssl_domain = 10.0
    elif has_http:
        url = host_data.get('url', '')
        if url.startswith('https'):
            # HTTPS URL but SSL check failed (handshake error, expired, etc.)
            ssl_domain = 6.0
        elif not url.startswith('https'):
            # HTTP-only, no TLS at all
            ssl_domain = 4.0

    # ── Domain 5: Attack Surface Breadth (0-10) ──
    breadth_domain = 0.0
    port_count = len(open_ports)
    if port_count > 0:
        # More open ports = wider attack surface. 1-2 is normal, 10+ is excessive.
        breadth_domain += min(port_count / 15.0, 0.5) * 10

    # Non-HTTP services increase attack surface complexity
    services = host_data.get('services', [])
    non_http_services = [s for s in services if s.get('name') not in ('http', 'https', 'tcpwrapped', 'unknown', '')]
    if non_http_services:
        breadth_domain += min(len(non_http_services) / 5.0, 0.3) * 10

    # Internet-facing without CDN = direct IP exposure
    if has_http and not host_data.get('cdn', False) and not has_waf:
        breadth_domain += 0.2 * 10

    breadth_domain = min(breadth_domain, 10.0)

    # ── Domain 6: Cloud Attack Surface Exposure (0-40) ──
    # Fed by the weighted cloud model (base_weight x exploitability x exposure).
    # A single max-weight finding (public bucket, leaked creds) can alone drive
    # a host to critical; additional findings add with diminishing returns.
    cloud_domain = 0.0
    cloud_hits = [v for v in host_vulns if v.get('source') == 'Cloud Exposure']
    if cloud_hits:
        cloud_scores = sorted((v.get('weighted_score') or 0) for v in cloud_hits)
        cloud_scores.reverse()
        top = cloud_scores[0]
        rest = sum(cloud_scores[1:])
        cloud_raw = top + 0.25 * rest
        cloud_domain = min(cloud_raw / 100.0, 1.0) * 40

    total = vuln_domain + secret_domain + posture_domain + ssl_domain + breadth_domain + cloud_domain
    return max(0, min(int(round(total)), 100))


def risk_band(score):
    if score >= 70:
        return 'critical'
    if score >= 45:
        return 'high'
    if score >= 20:
        return 'medium'
    return 'low'


def risk_grade(org_score):
    if org_score <= 10:
        return 'A'
    if org_score <= 20:
        return 'B'
    if org_score <= 35:
        return 'C'
    if org_score <= 55:
        return 'D'
    return 'F'


def compute_risk_scores(hosts, vulns):
    """Mutates hosts dict to add risk_score, risk_band, and domain breakdown."""
    host_vulns = {}
    for v in vulns:
        h = v.get('host', 'Unknown')
        host_vulns.setdefault(h, []).append(v)
        url = v.get('url', '')
        if url:
            try:
                url_host = url.split('//')[1].split('/')[0].split(':')[0]
                if url_host != h:
                    host_vulns.setdefault(url_host, []).append(v)
            except Exception:
                pass

    for host, host_data in hosts.items():
        hv = host_vulns.get(host, [])
        score = compute_host_risk(host, host_data, hv)
        host_data['risk_score'] = score
        host_data['risk_band'] = risk_band(score)


def compute_org_risk(hosts):
    """Org-level risk: weighted top-N with concentration and breadth penalties.

    A CRO cares about: worst-case exposure (top hosts), how concentrated the
    risk is (many critical hosts vs one), and what fraction of the surface is
    exposed (breadth ratio).
    """
    scores = sorted([h.get('risk_score', 0) for h in hosts.values()], reverse=True)
    if not scores:
        return 0, 'A'

    total_hosts = len(scores)

    # Base: weighted average of top 20% (min 3 hosts) — worst-case exposure
    top_n = max(3, total_hosts // 5)
    top_scores = scores[:top_n]
    base = sum(top_scores) / len(top_scores)

    # Concentration penalty: multiple critical hosts compound org risk
    critical_count = sum(1 for s in scores if s >= 70)
    high_count = sum(1 for s in scores if 45 <= s < 70)
    concentration = min(critical_count * 4 + high_count * 1.5, 25)

    # Breadth penalty: what % of hosts carry material risk (score >= 20)
    at_risk = sum(1 for s in scores if s >= 20)
    breadth_ratio = at_risk / total_hosts if total_hosts else 0
    breadth_penalty = breadth_ratio * 10

    # Dangling domain penalty: each dangling sub is a takeover vector
    dangling_count = sum(1 for h in hosts.values() if h.get('ssl_dangling'))
    dangling_penalty = min(dangling_count * 3, 10)

    org_score = max(0, min(int(round(base + concentration + breadth_penalty + dangling_penalty)), 100))
    return org_score, risk_grade(org_score)


# ===========================================================================
# DATA ACCESS LAYER
# ===========================================================================

def get_latest_scan_id():
    """Return the newest scan folder id, or None if nothing exists."""
    scans = get_available_scans()
    return scans[0]['id'] if scans else None


def resolve_target(scan_id):
    """Resolve scan folder id from scan id, target name, or empty latest selection."""
    if not scan_id:
        return get_latest_scan_id()

    scan_dir = os.path.join(BASE_SCAN_DIR, scan_id)
    if os.path.isdir(scan_dir):
        return scan_id

    target_scans = get_scans_for_target(scan_id)
    return target_scans[0]['id'] if target_scans else scan_id


def _cache_key(scan_id):
    return scan_id


def get_cached_scan_data(scan_id):
    """Return cached scan data when fresh enough."""
    cache_key = _cache_key(scan_id)
    entry = _SCAN_CACHE.get(cache_key)
    now = time.time()
    if entry and (now - entry.get('timestamp', 0) < CACHE_TIMEOUT):
        return entry['data']

    data = get_scan_data(scan_id, use_cache=False)
    if data:
        _SCAN_CACHE[cache_key] = {'timestamp': now, 'data': data}
    return data


def get_available_scans(use_cache=True):
    """List all completed scans"""
    now = time.time()
    if use_cache and _SCAN_INDEX_CACHE['scans'] and now - _SCAN_INDEX_CACHE['timestamp'] < CACHE_TIMEOUT:
        return _SCAN_INDEX_CACHE['scans']

    scans = []
    
    if not os.path.exists(BASE_SCAN_DIR):
        return scans
    
    for item in sorted(os.listdir(BASE_SCAN_DIR), reverse=True):
        item_path = os.path.join(BASE_SCAN_DIR, item)
        if not os.path.isdir(item_path):
            continue
        
        manifest_file = os.path.join(item_path, 'manifest.json')
        if not os.path.exists(manifest_file):
            continue
        
        try:
            with open(manifest_file, 'r') as f:
                manifest = json.load(f)

            pipeline_info = manifest.get('pipeline_info', {})
            stats = manifest.get('statistics', {})

            start_time = pipeline_info.get('start_time', '')
            target = pipeline_info.get('target', item)
            scans.append({
                'id': item,
                'name': target,
                'target': target,
                'status': pipeline_info.get('status', 'unknown'),
                'start_time': start_time,
                'end_time': stats.get('end_time', pipeline_info.get('end_time', '')),
                'scan_time_sort': scan_time_key(start_time, os.path.getmtime(item_path)),
                'total_hosts': stats.get('total_hosts', 0),
                'http_hosts': stats.get('http_hosts', 0),
                'waf_hosts': stats.get('waf_hosts', 0),
                'total_ports': stats.get('total_ports', stats.get('open_ports', 0))
            })
        except Exception as exc:
            logger.error("Failed to read scan manifest %s: %s", manifest_file, exc)

    scans.sort(key=lambda scan: scan.get('scan_time_sort', 0), reverse=True)
    _SCAN_INDEX_CACHE['timestamp'] = now
    _SCAN_INDEX_CACHE['scans'] = scans
    return scans


def get_scans_for_target(target):
    """Return all scans belonging to a target name, newest first."""
    return [scan for scan in get_available_scans() if scan.get('target') == target or scan.get('name') == target]


def get_target_summaries():
    """Group revisions by target so the UI behaves like an EASM monitor."""
    grouped = {}
    for scan in get_available_scans():
        target = scan.get('target') or scan.get('name') or scan['id']
        grouped.setdefault(target, []).append(scan)

    targets = []
    for target, scans in grouped.items():
        scans.sort(key=lambda scan: scan.get('scan_time_sort', 0), reverse=True)
        latest = scans[0]
        previous = scans[1] if len(scans) > 1 else None
        targets.append({
            'id': target,
            'name': target,
            'target': target,
            'status': latest.get('status', 'unknown'),
            'scan_id': latest['id'],
            'latest_scan_id': latest['id'],
            'previous_scan_id': previous['id'] if previous else None,
            'revision_count': len(scans),
            'start_time': latest.get('start_time', ''),
            'total_hosts': latest.get('total_hosts', 0),
            'http_hosts': latest.get('http_hosts', 0),
            'waf_hosts': latest.get('waf_hosts', 0),
            'total_ports': latest.get('total_ports', 0)
        })

    targets.sort(key=lambda target: scan_time_key(target.get('start_time')), reverse=True)
    return targets

def get_scan_data(scan_id, use_cache=True):
    """Get complete data for a scan"""
    scan_dir = os.path.join(BASE_SCAN_DIR, scan_id)
    
    if not os.path.isdir(scan_dir):
        return None

    if use_cache:
        cache_key = _cache_key(scan_id)
        entry = _SCAN_CACHE.get(cache_key)
        now = time.time()
        if entry and (now - entry.get('timestamp', 0) < CACHE_TIMEOUT):
            return entry['data']
    
    pipeline = ScanDataPipeline(scan_dir)
    manifest = pipeline.load_manifest()
    ports_data = pipeline.load_port_data()
    services = pipeline.load_service_data()
    vulns = pipeline.load_vulnerabilities()
    hosts = pipeline.aggregate_host_data(manifest, ports_data, services, vulns)
    
    port_scan_status = pipeline.get_port_scan_status()

    data = {
        'id': scan_id,
        'manifest': manifest,
        'hosts': hosts,
        'ports_data': ports_data,
        'services': services,
        'vulnerabilities': vulns,
        'pipeline_info': manifest.get('pipeline_info', {}),
        'statistics': manifest.get('statistics', {}),
        'port_scan_status': port_scan_status
    }
    if use_cache:
        _SCAN_CACHE[_cache_key(scan_id)] = {'timestamp': time.time(), 'data': data}
    return data


def get_previous_scan_id(scan_id):
    data = get_cached_scan_data(scan_id)
    if not data:
        return None
    target = data.get('pipeline_info', {}).get('target')
    if not target:
        return None
    scans = get_scans_for_target(target)
    for index, scan in enumerate(scans):
        if scan['id'] == scan_id and index + 1 < len(scans):
            return scans[index + 1]['id']
    return None


def _port_set(data):
    ports = set()
    for host, host_data in data.get('hosts', {}).items():
        for port in host_data.get('ports_open', []):
            try:
                ports.add(f"{host}:{int(port)}")
            except Exception:
                continue
    return ports


def _vuln_key(vuln):
    return '|'.join(str(vuln.get(field, '')) for field in ('source', 'template', 'host', 'url', 'severity'))


def compare_scans(current_scan_id, previous_scan_id=None):
    current = get_cached_scan_data(current_scan_id)
    if not current:
        return {}

    previous_scan_id = previous_scan_id or get_previous_scan_id(current_scan_id)
    previous = get_cached_scan_data(previous_scan_id) if previous_scan_id else None

    current_hosts = set(current.get('hosts', {}).keys())
    current_ports = _port_set(current)
    current_vulns = {_vuln_key(v): v for v in current.get('vulnerabilities', [])}

    if not previous:
        return {
            'target': current.get('pipeline_info', {}).get('target', current_scan_id),
            'current_scan_id': current_scan_id,
            'previous_scan_id': None,
            'has_baseline': False,
            'summary': {
                'new_hosts': len(current_hosts),
                'removed_hosts': 0,
                'new_ports': len(current_ports),
                'removed_ports': 0,
                'new_vulnerabilities': len(current_vulns),
                'removed_vulnerabilities': 0
            },
            'hosts': {'added': sorted(current_hosts), 'removed': []},
            'ports': {'added': sorted(current_ports), 'removed': []},
            'vulnerabilities': {'added': list(current_vulns.values()), 'removed': []}
        }

    previous_hosts = set(previous.get('hosts', {}).keys())
    previous_ports = _port_set(previous)
    previous_vulns = {_vuln_key(v): v for v in previous.get('vulnerabilities', [])}

    added_hosts = sorted(current_hosts - previous_hosts)
    removed_hosts = sorted(previous_hosts - current_hosts)
    added_ports = sorted(current_ports - previous_ports)
    removed_ports = sorted(previous_ports - current_ports)
    added_vuln_keys = sorted(set(current_vulns) - set(previous_vulns))
    removed_vuln_keys = sorted(set(previous_vulns) - set(current_vulns))

    return {
        'target': current.get('pipeline_info', {}).get('target', current_scan_id),
        'current_scan_id': current_scan_id,
        'previous_scan_id': previous_scan_id,
        'has_baseline': True,
        'summary': {
            'new_hosts': len(added_hosts),
            'removed_hosts': len(removed_hosts),
            'new_ports': len(added_ports),
            'removed_ports': len(removed_ports),
            'new_vulnerabilities': len(added_vuln_keys),
            'removed_vulnerabilities': len(removed_vuln_keys)
        },
        'hosts': {'added': added_hosts, 'removed': removed_hosts},
        'ports': {'added': added_ports, 'removed': removed_ports},
        'vulnerabilities': {
            'added': [current_vulns[key] for key in added_vuln_keys],
            'removed': [previous_vulns[key] for key in removed_vuln_keys]
        }
    }

# ===========================================================================
# API ROUTES
# ===========================================================================

@app.route('/')
def dashboard():
    """Main dashboard page"""
    return render_template('dashboard.html')

@app.route('/kt')
def knowledge_transfer():
    """Knowledge Transfer document for ARISE"""
    return render_template('kt.html')

@app.route('/api/scans')
def api_scans():
    """List all available scans"""
    scans = get_available_scans()
    return jsonify(scans)


@app.route('/api/targets/history')
def api_target_history():
    target = request.args.get('target')
    scan_id = resolve_target(target)
    data = get_cached_scan_data(scan_id) if scan_id else None
    resolved_target = data.get('pipeline_info', {}).get('target') if data else target
    return jsonify(get_scans_for_target(resolved_target) if resolved_target else [])


@app.route('/api/compare')
def api_compare():
    scan_id = resolve_target(request.args.get('target'))
    previous = request.args.get('previous')
    if not scan_id:
        return jsonify({})
    return jsonify(compare_scans(scan_id, previous))

@app.route('/api/scan/<scan_id>')
def api_scan(scan_id):
    """Get complete scan data"""
    data = get_scan_data(scan_id)
    
    if not data:
        return jsonify({'error': 'Scan not found'}), 404
    
    return jsonify({
        'id': data['id'],
        'pipeline_info': data['pipeline_info'],
        'statistics': data['statistics'],
        'hosts_count': len(data['hosts']),
        'ports_count': len(data['ports_data']),
        'vulnerabilities_count': len(data['vulnerabilities'])
    })

@app.route('/api/scan/<scan_id>/hosts')
def api_hosts(scan_id):
    """Get hosts for a scan"""
    data = get_scan_data(scan_id)
    
    if not data:
        return jsonify([]), 404
    
    hosts_list = []
    for host, host_data in data['hosts'].items():
        hosts_list.append({
            'name': host,
            'ip': host_data.get('ip', ''),
            'resolved': host_data.get('resolved', False),
            'http_status': host_data.get('http_status', ''),
            'waf_vendor': host_data.get('waf_vendor', 'none'),
            'security_score': host_data.get('security_header_score', 0),
            'ports': sorted(host_data.get('ports_open', [])),
            'services': host_data.get('services', []),
            'cdn': host_data.get('cdn', False),
            'risk_score': host_data.get('risk_score', 0),
            'risk_band': host_data.get('risk_band', 'low')
        })

    return jsonify(hosts_list)

@app.route('/api/scan/<scan_id>/ports')
def api_ports(scan_id):
    """Get ports for a scan"""
    data = get_scan_data(scan_id)
    
    if not data:
        return jsonify([]), 404
    
    # Group by port
    port_map = {}
    for host, ports in data['ports_data'].items():
        for port in ports:
            port_num = int(port)
            if port_num not in port_map:
                port_map[port_num] = {
                    'port': port_num,
                    'service': PORT_MAPPINGS.get(port_num, 'Unknown'),
                    'hosts': []
                }
            port_map[port_num]['hosts'].append({
                'host': host,
                'ip': data['hosts'].get(host, {}).get('ip', ''),
                'http_status': data['hosts'].get(host, {}).get('http_status', '')
            })
    
    # Sort by port number
    result = [port_map[p] for p in sorted(port_map.keys())]
    return jsonify(result)

@app.route('/api/scan/<scan_id>/vulnerabilities')
def api_vulnerabilities(scan_id):
    """Get vulnerabilities for a scan"""
    data = get_scan_data(scan_id)
    
    if not data:
        return jsonify([]), 404
    
    # Sort by severity
    severity_order = {"critical": 0, "high": 1, "medium": 2, "low": 3, "info": 4}
    vulns = sorted(
        data['vulnerabilities'],
        key=lambda x: severity_order.get(x.get('severity', 'info'), 4)
    )
    
    return jsonify(vulns)

@app.route('/api/scan/<scan_id>/statistics')
def api_statistics(scan_id):
    """Get statistics for a scan"""
    data = get_scan_data(scan_id)
    
    if not data:
        return jsonify({}), 404
    
    hosts = data['hosts']
    
    return jsonify({
        'total_hosts': len(hosts),
        'resolved_hosts': sum(1 for h in hosts.values() if h.get('resolved')),
        'http_hosts': sum(1 for h in hosts.values() if h.get('http_status')),
        'waf_hosts': sum(1 for h in hosts.values() if h.get('waf_vendor') != 'none'),
        'cdn_hosts': sum(1 for h in hosts.values() if h.get('cdn')),
        'total_vulnerabilities': len(data['vulnerabilities']),
        'total_ports': sum(len(h.get('ports_open', [])) for h in hosts.values()),
        'non_http_services': sum(1 for h in hosts.values() if h.get('services')),
        'port_scan_status': data.get('port_scan_status', 'missing')
    })

@app.route('/api/scan/<scan_id>/modules')
def api_modules(scan_id):
    """Get module status for a scan"""
    scan_dir = os.path.join(BASE_SCAN_DIR, scan_id)
    
    if not os.path.isdir(scan_dir):
        return jsonify({}), 404
    
    modules = {}
    module_names = {
        '01_asset_discovery': 'Asset Discovery',
        '02_subdomain_enum': 'Subdomain Enumeration',
        '03_dns_resolution': 'DNS Resolution',
        '04_http_discovery': 'HTTP Discovery',
        '05_waf_detection': 'WAF Detection',
        '06_header_analysis': 'Header Analysis',
        '07_service_fingerprint': 'Service Fingerprinting',
        '08_directory_discovery': 'Directory Discovery',
        '09_crawling': 'Web Crawling',
        '10_secret_scanning': 'Secret Scanning',
        '11_param_fuzzing': 'Parameter Fuzzing',
        '12_nuclei_scanning': 'Vulnerability Scanning',
        '13_xss_testing': 'XSS Testing',
        '14_port_scan': 'Port Scanning',
        '15_sqli_testing': 'SQLi Testing',
        '16_api_security': 'API Security Testing',
        '17_cloud_exposure': 'Cloud Exposure',
        '19_extended_checks': 'Extended Verification',
    }

    for module_dir, module_name in module_names.items():
        module_path = os.path.join(scan_dir, module_dir)
        completed = False
        data_count = 0
        
        if os.path.isdir(module_path):
            files = glob.glob(os.path.join(module_path, '*'))
            data_count = len([f for f in files if os.path.isfile(f)])
            completed = data_count > 0
        
        modules[module_dir] = {
            'name': module_name,
            'completed': completed,
            'data_count': data_count
        }
    
    return jsonify(modules)


@app.route('/api/scan/<scan_id>/history')
def api_scan_history(scan_id):
    data = get_cached_scan_data(scan_id)
    if not data:
        return jsonify([]), 404
    target = data.get('pipeline_info', {}).get('target')
    return jsonify(get_scans_for_target(target))


@app.route('/api/scan/<scan_id>/compare')
def api_scan_compare(scan_id):
    if not get_cached_scan_data(scan_id):
        return jsonify({}), 404
    return jsonify(compare_scans(scan_id, request.args.get('previous')))


@app.route('/api/scan/<scan_id>/risk')
def api_risk(scan_id):
    """Per-host and org-level risk scores."""
    data = get_cached_scan_data(scan_id)
    if not data:
        return jsonify({}), 404

    hosts = data.get('hosts', {})
    org_score, grade = compute_org_risk(hosts)

    bands = {'critical': 0, 'high': 0, 'medium': 0, 'low': 0}
    host_scores = []
    for host, hd in hosts.items():
        band = hd.get('risk_band', 'low')
        bands[band] = bands.get(band, 0) + 1
        host_scores.append({
            'host': host,
            'score': hd.get('risk_score', 0),
            'band': band
        })

    host_scores.sort(key=lambda x: x['score'], reverse=True)
    return jsonify({
        'org_score': org_score,
        'grade': grade,
        'band_distribution': bands,
        'host_scores': host_scores
    })


def _classify_provider(*blobs):
    """Map httpx tech / CDN / server strings to a canonical cloud provider."""
    text = ' '.join(str(b or '') for b in blobs).lower()
    for provider, needles in CLOUD_PROVIDER_TECH.items():
        if any(n in text for n in needles):
            return provider
    return None


def build_cloud_recon(scan_id):
    """Cloud-estate inventory derived from HTTP discovery + bucket enumeration.

    This is recon, not vulnerabilities: which providers/CDNs front the estate,
    which origin IPs sit exposed, and which storage buckets were discovered.
    """
    recon = {
        'providers': {}, 'cdn_breakdown': {}, 'origin_ips': [],
        'buckets': [], 'cloud_hosts': 0, 'total_hosts': 0,
        'bucket_summary': {'total': 0, 'public': 0, 'private': 0},
    }
    if not scan_id:
        return recon

    scan_root = os.path.join(BASE_SCAN_DIR, scan_id)
    http_file = os.path.join(scan_root, '04_http_discovery/http_confirmed.json')
    seen_hosts = set()
    origin_seen = set()

    if os.path.exists(http_file):
        try:
            with open(http_file, 'r', errors='ignore') as f:
                for line in f:
                    line = line.strip()
                    if not line:
                        continue
                    try:
                        e = json.loads(line)
                    except Exception:
                        continue
                    host = e.get('input') or e.get('host')
                    if not host or host in seen_hosts:
                        continue
                    seen_hosts.add(host)
                    recon['total_hosts'] += 1

                    tech = e.get('tech', []) or []
                    cdn_name = e.get('cdn_name') or ''
                    provider = _classify_provider(' '.join(tech), cdn_name,
                                                  e.get('webserver', ''))
                    if provider:
                        recon['cloud_hosts'] += 1
                        recon['providers'][provider] = recon['providers'].get(provider, 0) + 1

                    # CDN inventory
                    if e.get('cdn') and cdn_name:
                        label = cdn_name.title()
                        recon['cdn_breakdown'][label] = recon['cdn_breakdown'].get(label, 0) + 1

                    # Exposed origins: a resolved host that is NOT behind a CDN
                    # but sits on a cloud provider is a direct-origin candidate.
                    ip = e.get('host_ip') or (e.get('a') or [''])[0]
                    if ip and not e.get('cdn') and provider and ip not in origin_seen:
                        origin_seen.add(ip)
                        recon['origin_ips'].append({
                            'host': host, 'ip': ip, 'provider': provider,
                            'cdn': False, 'server': e.get('webserver', ''),
                        })
        except Exception as exc:
            logger.error("Failed to build cloud recon from %s: %s", http_file, exc)

    # Phase 2 — bucket enumeration output (CloudEnum + S3Scanner)
    buckets_file = os.path.join(scan_root, '17_cloud_exposure/cloud_buckets.jsonl')
    if os.path.exists(buckets_file):
        try:
            with open(buckets_file, 'r', errors='ignore') as f:
                for line in f:
                    line = line.strip()
                    if not line:
                        continue
                    try:
                        b = json.loads(line)
                    except Exception:
                        continue
                    access = (b.get('access') or 'unknown').lower()
                    recon['buckets'].append({
                        'name': b.get('name', ''),
                        'provider': (b.get('provider') or 'aws').lower(),
                        'access': access,
                        'url': b.get('url', ''),
                        'files': b.get('files', 0),
                        'note': b.get('note', ''),
                    })
                    recon['bucket_summary']['total'] += 1
                    if access in ('public', 'open', 'listable'):
                        recon['bucket_summary']['public'] += 1
                    else:
                        recon['bucket_summary']['private'] += 1
        except Exception as exc:
            logger.error("Failed to read cloud buckets %s: %s", buckets_file, exc)

    recon['origin_ips'] = recon['origin_ips'][:50]
    recon['buckets'].sort(key=lambda x: (x['access'] != 'public', x['name']))
    return recon


def load_cloud_compliance(scan_id):
    """Phase 3 — authenticated compliance audit (Prowler / ScoutSuite).

    Only present when the operator ran an authenticated audit with cloud
    credentials. Absent (enabled=False) for pure external scans.
    """
    result = {'enabled': False, 'findings': [], 'by_service': {},
              'by_severity': {'critical': 0, 'high': 0, 'medium': 0, 'low': 0, 'info': 0},
              'tool': None, 'total': 0}
    if not scan_id:
        return result
    comp_file = os.path.join(BASE_SCAN_DIR, scan_id, '17_cloud_exposure/cloud_compliance.jsonl')
    if not os.path.exists(comp_file):
        return result
    try:
        with open(comp_file, 'r', errors='ignore') as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                try:
                    c = json.loads(line)
                except Exception:
                    continue
                result['enabled'] = True
                sev = (c.get('severity') or 'info').lower()
                svc = c.get('service', 'general')
                result['tool'] = result['tool'] or c.get('tool')
                result['findings'].append({
                    'check_id': c.get('check_id', ''),
                    'title': c.get('title', ''),
                    'service': svc,
                    'severity': sev,
                    'status': c.get('status', 'FAIL'),
                    'region': c.get('region', ''),
                    'resource': c.get('resource', ''),
                    'framework': c.get('framework', ''),
                    'remediation': c.get('remediation', ''),
                })
                result['by_service'][svc] = result['by_service'].get(svc, 0) + 1
                if sev in result['by_severity']:
                    result['by_severity'][sev] += 1
    except Exception as exc:
        logger.error("Failed to read cloud compliance %s: %s", comp_file, exc)
    result['findings'].sort(key=lambda x: {'critical': 0, 'high': 1, 'medium': 2,
                                           'low': 3, 'info': 4}.get(x['severity'], 5))
    result['total'] = len(result['findings'])
    return result


@app.route('/api/scan/<scan_id>/cloud')
def api_cloud(scan_id):
    """Cloud attack surface — infrastructure security findings + cloud recon.

    Strictly cloud-scoped: app/API vulnerabilities (XSS, SQLi, SSRF, IDOR, JWT)
    are excluded by the CLOUD_ALL_CATEGORIES whitelist and live in the Vulns/API
    tabs instead.
    """
    data = get_cached_scan_data(scan_id)
    if not data:
        return jsonify({}), 404

    cloud = [v for v in data.get('vulnerabilities', [])
             if v.get('source') == 'Cloud Exposure'
             and v.get('cloud_category') in CLOUD_ALL_CATEGORIES]
    cloud.sort(key=lambda v: v.get('weighted_score', 0), reverse=True)

    by_category = {}
    sev_counts = {'critical': 0, 'high': 0, 'medium': 0, 'low': 0, 'info': 0}
    security_count = 0
    posture_count = 0
    for v in cloud:
        cat = v.get('cloud_category', 'unknown')
        if cat in CLOUD_SECURITY_CATEGORIES:
            security_count += 1
        else:
            posture_count += 1
        entry = by_category.setdefault(cat, {
            'label': v.get('template', cat),
            'base_weight': v.get('base_weight', 0),
            'count': 0,
            'max_score': 0,
            'group': 'security' if cat in CLOUD_SECURITY_CATEGORIES else 'posture',
        })
        entry['count'] += 1
        entry['max_score'] = max(entry['max_score'], v.get('weighted_score', 0))
        sev = v.get('severity', 'info')
        sev_counts[sev] = sev_counts.get(sev, 0) + 1

    categories = sorted(by_category.values(), key=lambda c: c['max_score'], reverse=True)
    return jsonify({
        'total': len(cloud),
        'security_count': security_count,
        'posture_count': posture_count,
        'by_severity': sev_counts,
        'categories': categories,
        'findings': cloud,
        'recon': build_cloud_recon(scan_id),
        'compliance': load_cloud_compliance(scan_id),
    })


@app.route('/api/scan/<scan_id>/executive')
def api_executive(scan_id):
    """Executive / CXO summary."""
    data = get_cached_scan_data(scan_id)
    if not data:
        return jsonify({}), 404

    hosts = data.get('hosts', {})
    vulns = data.get('vulnerabilities', [])
    org_score, grade = compute_org_risk(hosts)

    total_assets = len(hosts)
    http_hosts = sum(1 for h in hosts.values() if h.get('http_status'))
    resolved = sum(1 for h in hosts.values() if h.get('resolved'))
    waf_covered = sum(1 for h in hosts.values()
                      if h.get('waf_vendor') not in ('none', '', None) and h.get('http_status'))
    waf_uncovered = http_hosts - waf_covered
    waf_coverage_pct = round(waf_covered * 100 / http_hosts) if http_hosts else 0
    cdn_fronted = sum(1 for h in hosts.values() if h.get('cdn'))

    sev_counts = {'critical': 0, 'high': 0, 'medium': 0, 'low': 0, 'info': 0}
    for v in vulns:
        s = v.get('severity', 'info')
        sev_counts[s] = sev_counts.get(s, 0) + 1

    secrets_count = sum(1 for v in vulns if v.get('source') == 'Secret Scan')

    sensitive_services = []
    for host, hd in hosts.items():
        exposed = set(hd.get('ports_open', [])) & SENSITIVE_PORTS
        for p in exposed:
            sensitive_services.append({'host': host, 'port': p, 'service': PORT_MAPPINGS.get(p, 'Unknown')})

    delta = compare_scans(scan_id)

    # Top 5 remediation priorities
    scored_items = []
    for v in vulns:
        prio = SEVERITY_WEIGHTS.get(v.get('severity', 'info'), 0)
        if v.get('source') == 'Secret Scan':
            prio += 25
        scored_items.append((prio, v))
    for s in sensitive_services:
        scored_items.append((15, {
            'source': 'Port Scan',
            'template': f"Exposed {s['service']}",
            'severity': 'high',
            'host': s['host'],
            'url': f"{s['host']}:{s['port']}",
            'impact': f"Sensitive service {s['service']} exposed to internet",
            'remediation': 'Restrict access via firewall or VPN'
        }))
    scored_items.sort(key=lambda x: x[0], reverse=True)
    top_priorities = [item[1] for item in scored_items[:5]]

    # Historical trend
    scan_history = get_scans_for_target(data.get('pipeline_info', {}).get('target', ''))
    trend = []
    for s in scan_history[:10]:
        hist_data = get_cached_scan_data(s['id'])
        if hist_data:
            h_score, h_grade = compute_org_risk(hist_data.get('hosts', {}))
            trend.append({
                'scan_id': s['id'],
                'start_time': s.get('start_time', ''),
                'org_score': h_score,
                'grade': h_grade,
                'total_hosts': s.get('total_hosts', 0),
                'vuln_count': len(hist_data.get('vulnerabilities', []))
            })

    return jsonify({
        'org_score': org_score,
        'grade': grade,
        'exposure': {
            'total_assets': total_assets,
            'internet_facing_http': http_hosts,
            'resolved': resolved,
            'waf_covered': waf_covered,
            'waf_uncovered': waf_uncovered,
            'waf_coverage_pct': waf_coverage_pct,
            'cdn_fronted': cdn_fronted
        },
        'findings': {
            'by_severity': sev_counts,
            'secrets': secrets_count,
            'sensitive_services': len(sensitive_services)
        },
        'delta': delta.get('summary', {}),
        'has_baseline': delta.get('has_baseline', False),
        'top_priorities': top_priorities,
        'trend': trend,
        'port_scan_status': data.get('port_scan_status', 'missing')
    })


@app.route('/api/scan/<scan_id>/cves')
def api_cves(scan_id):
    """CVE-grouped vulnerability view."""
    data = get_cached_scan_data(scan_id)
    if not data:
        return jsonify([]), 404

    cve_map = {}
    for v in data.get('vulnerabilities', []):
        cve_ids = v.get('cve_id') or []
        if isinstance(cve_ids, str):
            cve_ids = [cve_ids] if cve_ids else []
        for cve_id in cve_ids:
            if not cve_id:
                continue
            if cve_id not in cve_map:
                cve_map[cve_id] = {
                    'cve_id': cve_id,
                    'severity': v.get('severity', 'info'),
                    'template': v.get('template', ''),
                    'cwe_ids': [],
                    'affected_hosts': [],
                    'count': 0
                }
            entry = cve_map[cve_id]
            entry['count'] += 1
            host = v.get('host', 'Unknown')
            if host not in entry['affected_hosts']:
                entry['affected_hosts'].append(host)
            cwe = v.get('cwe_id', [])
            if isinstance(cwe, str):
                cwe = [cwe]
            for c in cwe:
                if c and c not in entry['cwe_ids']:
                    entry['cwe_ids'].append(c)

    severity_order = {'critical': 0, 'high': 1, 'medium': 2, 'low': 3, 'info': 4}
    result = sorted(cve_map.values(), key=lambda x: (severity_order.get(x['severity'], 4), -x['count']))
    return jsonify(result)


def _load_api_security_findings(scan_id):
    """Read the deduplicated, tool-tagged API security findings for a scan."""
    if not scan_id:
        return []
    findings_file = os.path.join(BASE_SCAN_DIR, scan_id, '16_api_security', 'api_findings.jsonl')
    findings = []
    if not os.path.exists(findings_file):
        return findings
    try:
        with open(findings_file, 'r', errors='ignore') as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                try:
                    findings.append(json.loads(line))
                except Exception:
                    continue
    except Exception as exc:
        logger.error("Failed to read API findings %s: %s", findings_file, exc)
    return findings


@app.route('/api/scan/<scan_id>/api-security')
def api_api_security(scan_id):
    """Deduplicated API security findings with per-tool tagging and a summary."""
    findings = _load_api_security_findings(scan_id)

    sev_rank = {'critical': 4, 'high': 3, 'medium': 2, 'low': 1, 'info': 0}
    findings.sort(key=lambda x: (-sev_rank.get(x.get('severity', 'info'), 0), x.get('path', '')))

    def _tool_count(tool):
        return sum(1 for f in findings if tool in (f.get('tools') or [f.get('tool')]))

    summary = {
        'total': len(findings),
        'autoswagger': _tool_count('autoswagger'),
        'restler': _tool_count('restler'),
        'multi_tool': sum(1 for f in findings if len(f.get('tools') or []) > 1),
        'unique_endpoints': len({f.get('endpoint') for f in findings if f.get('endpoint')}),
        'by_severity': {
            s: sum(1 for f in findings if f.get('severity') == s)
            for s in ('critical', 'high', 'medium', 'low', 'info')
        },
        'by_category': {},
    }
    for f in findings:
        cat = f.get('category', 'other')
        summary['by_category'][cat] = summary['by_category'].get(cat, 0) + 1

    return jsonify({'summary': summary, 'findings': findings})


@app.route('/api/api-security')
def api_api_security_legacy():
    """Legacy API security endpoint keyed by ?target=."""
    scan_id = resolve_target(request.args.get('target'))
    logger.info("API request: /api/api-security target=%s", scan_id)
    if not scan_id:
        return jsonify({'summary': {'total': 0, 'autoswagger': 0, 'restler': 0,
                                    'multi_tool': 0, 'unique_endpoints': 0,
                                    'by_severity': {}, 'by_category': {}}, 'findings': []})
    return api_api_security(scan_id)


@app.route('/api/cloud')
def api_cloud_legacy():
    """Cloud exposure endpoint keyed by ?target=."""
    scan_id = resolve_target(request.args.get('target'))
    logger.info("API request: /api/cloud target=%s", scan_id)
    if not scan_id:
        return jsonify({
            'total': 0, 'security_count': 0, 'posture_count': 0,
            'by_severity': {}, 'categories': [], 'findings': [],
            'recon': build_cloud_recon(None),
            'compliance': load_cloud_compliance(None),
        })
    return api_cloud(scan_id)


def _legacy_host_rows(scan_id):
    data = get_cached_scan_data(scan_id)
    if not data:
        return []

    rows = []
    for host, host_data in data['hosts'].items():
        rows.append({
            'host': host,
            'ip': host_data.get('ip', ''),
            'resolved': host_data.get('resolved', False),
            'http_status': host_data.get('http_status', ''),
            'cdn': host_data.get('cdn', False),
            'waf_vendor': host_data.get('waf_vendor', 'none'),
            'skip_bruteforce': host_data.get('skip_bruteforce', False),
            'security_score': host_data.get('security_header_score', 0),
            'server_banner': host_data.get('server_banner', ''),
            'service_type': host_data.get('service_type', 'http'),
            'ports_open': sorted(set(host_data.get('ports_open', []))),
            'cve_count': len(host_data.get('cve_candidates', [])),
            'risk_score': host_data.get('risk_score', 0),
            'risk_band': host_data.get('risk_band', 'low'),
            'ssl_dangling': host_data.get('ssl_dangling', False),
            'ssl_cert_cn': host_data.get('ssl_cert_cn', ''),
            'ssl_checked': host_data.get('ssl_checked', False),
            'is_api': host_data.get('is_api', False),
            'api_signals': host_data.get('api_signals', []),
        })
    return rows


def _legacy_port_rows(scan_id):
    data = get_cached_scan_data(scan_id)
    if not data:
        return []

    port_map = {}
    for host, host_data in data['hosts'].items():
        ip = host_data.get('ip', '')
        services_list = host_data.get('services', [])
        
        # Build a quick lookup for port -> service name
        port_service_map = {}
        for srv in services_list:
            if 'port' in srv and 'name' in srv:
                port_service_map[int(srv['port'])] = srv['name']
                
        for port in sorted(set(host_data.get('ports_open', []))):
            port = int(port)
            
            # Get service name from Nmap, fallback to HTTP logic if missing
            service_name = port_service_map.get(port)
            if not service_name or service_name == 'unknown':
                if port == 443 or port == 8443:
                    service_name = 'https'
                elif port == 80 or port == 8080:
                    service_name = 'http'
                else:
                    service_name = 'unknown'

            port_map.setdefault(port, {'port': port, 'host_count': 0, 'hosts': []})
            port_map[port]['hosts'].append({
                'host': host,
                'ip': ip,
                'http_status': host_data.get('http_status', ''),
                'waf': host_data.get('waf_vendor', 'none') != 'none',
                'service': service_name
            })
            port_map[port]['host_count'] = len({entry['host'] for entry in port_map[port]['hosts']})

    return [port_map[port] for port in sorted(port_map)]


@app.route('/api/targets')
def api_targets_legacy():
    """Legacy target list for the older frontend."""
    logger.info("API request: /api/targets")
    return jsonify(get_target_summaries())


@app.route('/api/status')
def api_status_legacy():
    """Legacy status endpoint."""
    scan_id = resolve_target(request.args.get('target'))
    logger.info("API request: /api/status target=%s", scan_id)
    data = get_cached_scan_data(scan_id) if scan_id else None
    if not data:
        return jsonify({'status': 'no_data', 'target': scan_id or '', 'message': 'No scan data available'})

    pipeline_info = data.get('pipeline_info', {})
    statistics = data.get('statistics', {})
    return jsonify({
        'status': pipeline_info.get('status', 'unknown'),
        'target': pipeline_info.get('target', scan_id),
        'version': pipeline_info.get('version', ''),
        'start_time': pipeline_info.get('start_time', ''),
        'scan_id': scan_id,
        'duration': statistics.get('duration_seconds', 0)
    })


@app.route('/api/statistics')
def api_statistics_legacy():
    """Legacy statistics endpoint."""
    scan_id = resolve_target(request.args.get('target'))
    logger.info("API request: /api/statistics target=%s", scan_id)
    data = get_cached_scan_data(scan_id) if scan_id else None
    if not data:
        return jsonify({})

    hosts = data.get('hosts', {})
    statistics = data.get('statistics', {})
    computed_http = sum(1 for h in hosts.values() if h.get('http_status'))
    computed_waf = sum(1 for h in hosts.values() if h.get('waf_vendor') not in ('none', '', None))
    return jsonify({
        'total_hosts': statistics.get('total_hosts', len(hosts)),
        'resolved_hosts': statistics.get('resolved_hosts', sum(1 for h in hosts.values() if h.get('resolved'))),
        'http_hosts': max(statistics.get('http_hosts', 0), computed_http),
        'waf_hosts': max(statistics.get('waf_hosts', 0), computed_waf),
        'cdn_hosts': statistics.get('cdn_hosts', sum(1 for h in hosts.values() if h.get('cdn'))),
        'non_http_services': statistics.get('non_http_services', sum(1 for h in hosts.values() if h.get('service_type') == 'non_http')),
        'total_vulnerabilities': len(data.get('vulnerabilities', [])),
        'total_ports': statistics.get('total_ports', sum(len(h.get('ports_open', [])) for h in hosts.values())),
        'open_ports': statistics.get('open_ports', sum(len(h.get('ports_open', [])) for h in hosts.values())),
        'services_fingerprinted': statistics.get('services_fingerprinted', sum(1 for h in hosts.values() if h.get('services'))),
        'total_urls': statistics.get('total_urls', 0),
        'total_js_files': statistics.get('total_js_files', 0),
        'total_secrets': statistics.get('total_secrets', 0),
        'port_scan_status': data.get('port_scan_status', statistics.get('port_scan_status', 'missing'))
    })


@app.route('/api/hosts')
def api_hosts_legacy():
    """Legacy hosts endpoint."""
    scan_id = resolve_target(request.args.get('target'))
    logger.info("API request: /api/hosts target=%s", scan_id)
    return jsonify(_legacy_host_rows(scan_id))


@app.route('/api/hosts/search')
def api_hosts_search():
    """Search endpoint — also respects an optional filter parameter."""
    scan_id = resolve_target(request.args.get('target'))
    query = request.args.get('q', '').strip().lower()
    filter_type = request.args.get('filter', 'all').strip()
    logger.info("API request: /api/hosts/search target=%s query=%s filter=%s", scan_id, query, filter_type)
    hosts = _legacy_host_rows(scan_id)
    hosts = _apply_host_filter(hosts, filter_type)
    if query:
        hosts = [h for h in hosts if query in h['host'].lower() or query in h['ip'].lower()]
    return jsonify(hosts)


@app.route('/api/hosts/filter/<filter_type>')
def api_hosts_filter(filter_type):
    """Filter endpoint — also respects an optional search query."""
    scan_id = resolve_target(request.args.get('target'))
    query = request.args.get('q', '').strip().lower()
    logger.info("API request: /api/hosts/filter/%s target=%s query=%s", filter_type, scan_id, query)
    hosts = _legacy_host_rows(scan_id)
    hosts = _apply_host_filter(hosts, filter_type)
    if query:
        hosts = [h for h in hosts if query in h['host'].lower() or query in h['ip'].lower()]
    return jsonify(hosts)


def _apply_host_filter(hosts, filter_type):
    if filter_type == 'waf':
        return [h for h in hosts if (h.get('waf_vendor') or '').lower() not in ('none', '')]
    elif filter_type == 'http':
        return [h for h in hosts if h.get('http_status')]
    elif filter_type == 'resolved':
        return [h for h in hosts if h.get('resolved')]
    elif filter_type == 'cdn':
        return [h for h in hosts if h.get('cdn')]
    elif filter_type == 'dangling':
        return [h for h in hosts if h.get('ssl_dangling')]
    elif filter_type == 'api':
        return [h for h in hosts if h.get('is_api')]
    return hosts


@app.route('/api/ports')
def api_ports_legacy():
    """Legacy ports endpoint."""
    scan_id = resolve_target(request.args.get('target'))
    logger.info("API request: /api/ports target=%s", scan_id)
    return jsonify(_legacy_port_rows(scan_id))


@app.route('/api/services')
def api_services():
    """Nmap service fingerprinting results with risk classification."""
    scan_id = resolve_target(request.args.get('target'))
    logger.info("API request: /api/services target=%s", scan_id)
    data = get_cached_scan_data(scan_id) if scan_id else None
    if not data:
        return jsonify({'services': [], 'summary': {}})

    hosts = data.get('hosts', {})
    rows = []
    proto_counts = {}
    for host, hd in hosts.items():
        svc_list = hd.get('services', [])
        open_ports = sorted(set(int(p) for p in hd.get('ports_open', [])))
        svc_map = {}
        for svc in svc_list:
            p = int(svc.get('port', 0))
            svc_map[p] = svc

        for port in open_ports:
            svc = svc_map.get(port, {})
            name = svc.get('name', PORT_MAPPINGS.get(port, 'unknown'))
            product = svc.get('product', '')
            version = svc.get('version', '')
            extra = svc.get('extrainfo', '')
            is_t1 = port in PORT_RISK_TIER1
            is_t2 = port in PORT_RISK_TIER2
            is_t3 = port in PORT_RISK_TIER3
            risk = 'critical' if is_t1 else 'high' if is_t2 else 'medium' if is_t3 else 'low'
            proto_counts[name] = proto_counts.get(name, 0) + 1

            rows.append({
                'host': host,
                'ip': hd.get('ip', ''),
                'port': port,
                'service': name,
                'product': product,
                'version': version,
                'extra': extra,
                'fingerprint': f"{product} {version}".strip() if product else '',
                'risk': risk,
                'waf': hd.get('waf_vendor', 'none'),
            })

    unique_hosts = len(set(r['host'] for r in rows))
    sensitive_count = sum(1 for r in rows if r['risk'] in ('critical', 'high'))
    top_services = sorted(proto_counts.items(), key=lambda x: x[1], reverse=True)[:10]

    return jsonify({
        'services': rows,
        'summary': {
            'total_ports': len(rows),
            'unique_hosts': unique_hosts,
            'sensitive_ports': sensitive_count,
            'unique_services': len(proto_counts),
            'top_services': [{'name': n, 'count': c} for n, c in top_services],
        }
    })


@app.route('/api/techstack')
def api_techstack():
    """Technology stack detected via httpx tech-detect across all hosts."""
    scan_id = resolve_target(request.args.get('target'))
    logger.info("API request: /api/techstack target=%s", scan_id)
    if not scan_id:
        return jsonify({'technologies': [], 'by_category': {}, 'total_hosts': 0})

    http_file = os.path.join(BASE_SCAN_DIR, scan_id, '04_http_discovery/http_confirmed.json')
    tech_counts = {}
    tech_hosts = {}
    total_hosts = 0

    TECH_CATEGORIES = {
        'Amazon Web Services': 'cloud', 'Amazon CloudFront': 'cdn', 'Amazon S3': 'cloud',
        'Amazon ELB': 'cloud', 'Google Cloud': 'cloud', 'Firebase': 'cloud',
        'Azure': 'cloud', 'Microsoft Azure': 'cloud', 'DigitalOcean': 'cloud',
        'Cloudflare': 'cdn', 'Cloudflare Bot Management': 'security',
        'Cloudflare Browser Insights': 'analytics', 'Fastly': 'cdn',
        'Akamai': 'cdn', 'Varnish': 'cdn', 'jsDelivr': 'cdn', 'cdnjs': 'cdn',
        'Nginx': 'web-server', 'Apache': 'web-server', 'IIS': 'web-server',
        'LiteSpeed': 'web-server', 'OpenResty': 'web-server', 'Envoy': 'web-server',
        'React': 'frontend', 'Vue.js': 'frontend', 'Angular': 'frontend',
        'jQuery': 'frontend', 'Bootstrap': 'frontend', 'Next.js': 'frontend',
        'Nuxt.js': 'frontend', 'Gatsby': 'frontend', 'Svelte': 'frontend',
        'Node.js': 'backend', 'Express': 'backend', 'Django': 'backend',
        'Flask': 'backend', 'Laravel': 'backend', 'Ruby on Rails': 'backend',
        'Spring': 'backend', 'ASP.NET': 'backend', 'Microsoft ASP.NET': 'backend',
        'PHP': 'backend', 'Python': 'backend', 'Go': 'backend', 'Java': 'backend',
        'WordPress': 'cms', 'Drupal': 'cms', 'Joomla': 'cms', 'Shopify': 'cms',
        'Magento': 'cms', 'Ghost': 'cms', 'Contentful': 'cms', 'Strapi': 'cms',
        'Google Analytics': 'analytics', 'Google Tag Manager': 'analytics',
        'Hotjar': 'analytics', 'Segment': 'analytics', 'Mixpanel': 'analytics',
        'HSTS': 'security', 'HTTP/3': 'protocol', 'HTTP/2': 'protocol',
        'GitHub Pages': 'hosting', 'Netlify': 'hosting', 'Vercel': 'hosting',
        'Heroku': 'hosting', 'Render': 'hosting',
        'Windows Server': 'os', 'Ubuntu': 'os', 'Debian': 'os', 'CentOS': 'os',
        'Redis': 'database', 'MySQL': 'database', 'PostgreSQL': 'database',
        'MongoDB': 'database', 'Elasticsearch': 'database',
    }

    CAT_LABELS = {
        'cloud': 'Cloud Provider', 'cdn': 'CDN / Edge', 'security': 'Security',
        'analytics': 'Analytics', 'web-server': 'Web Server', 'frontend': 'Frontend',
        'backend': 'Backend', 'cms': 'CMS', 'protocol': 'Protocol',
        'hosting': 'Hosting', 'os': 'Operating System', 'database': 'Database',
        'other': 'Other',
    }

    if os.path.exists(http_file):
        try:
            with open(http_file, 'r', errors='ignore') as f:
                for line in f:
                    try:
                        entry = json.loads(line.strip())
                    except Exception:
                        continue
                    host = entry.get('input') or entry.get('host')
                    if host:
                        total_hosts += 1
                    techs = entry.get('tech', [])
                    for t in techs:
                        clean = t.split(':')[0].strip()
                        tech_counts[clean] = tech_counts.get(clean, 0) + 1
                        tech_hosts.setdefault(clean, set()).add(host or '')
        except Exception as exc:
            logger.error("Failed to read tech stack from %s: %s", http_file, exc)

    by_category = {}
    technologies = []
    for name, count in sorted(tech_counts.items(), key=lambda x: x[1], reverse=True):
        cat = TECH_CATEGORIES.get(name, 'other')
        for prefix, prefix_cat in TECH_CATEGORIES.items():
            if name.startswith(prefix):
                cat = prefix_cat
                break
        technologies.append({
            'name': name,
            'count': count,
            'hosts': sorted(list(tech_hosts.get(name, set()))),
            'category': cat,
        })
        by_category.setdefault(cat, {'label': CAT_LABELS.get(cat, cat.title()), 'count': 0, 'techs': []})
        by_category[cat]['count'] += count
        by_category[cat]['techs'].append(name)

    return jsonify({
        'technologies': technologies,
        'by_category': by_category,
        'total_hosts': total_hosts,
    })


def _load_dirsearch(scan_id):
    """Read dirsearch results (200/403/500) for a scan into a flat list."""
    if not scan_id:
        return []
    dirsearch_dir = os.path.join(BASE_SCAN_DIR, scan_id, '08_directory_discovery', 'dirsearch')
    urls = []
    files_to_read = [
        ('200response.txt', 200),
        ('forbidden_response.txt', 403),
        ('500response.txt', 500),
    ]
    for filename, status_code in files_to_read:
        file_path = os.path.join(dirsearch_dir, filename)
        if os.path.exists(file_path):
            try:
                with open(file_path, 'r', errors='ignore') as f:
                    for line in f:
                        line = line.strip()
                        if line:
                            urls.append({"url": line, "status": status_code})
            except Exception as exc:
                logger.error("Failed to read dirsearch file %s: %s", file_path, exc)
    return urls


@app.route('/api/dirsearch')
def api_dirsearch():
    """Returns dirsearch results (200, 403, 500)."""
    scan_id = resolve_target(request.args.get('target'))
    logger.info("API request: /api/dirsearch target=%s", scan_id)
    return jsonify(_load_dirsearch(scan_id))


@app.route('/api/modules')
def api_modules_legacy():
    """Legacy module summary endpoint."""
    scan_id = resolve_target(request.args.get('target'))
    logger.info("API request: /api/modules target=%s", scan_id)
    scan_dir = os.path.join(BASE_SCAN_DIR, scan_id) if scan_id else None
    if not scan_dir or not os.path.isdir(scan_dir):
        return jsonify({})

    module_names = {
        '01_asset_discovery': 'Asset Discovery',
        '02_subdomain_enum': 'Subdomain Enumeration',
        '03_dns_resolution': 'DNS Resolution',
        '04_http_discovery': 'HTTP Discovery',
        '05_waf_detection': 'WAF Detection',
        '06_header_analysis': 'Header Analysis',
        '07_service_fingerprint': 'Service Fingerprinting',
        '08_directory_discovery': 'Directory Discovery',
        '09_crawling': 'Web Crawling',
        '10_secret_scanning': 'Secret Scanning',
        '11_param_fuzzing': 'Parameter Fuzzing',
        '12_nuclei_scanning': 'Vulnerability Scanning',
        '13_xss_testing': 'XSS Testing',
        '14_port_scan': 'Port Scanning',
        '15_sqli_testing': 'SQLi Testing',
        '16_api_security': 'API Security Testing',
        '17_cloud_exposure': 'Cloud Exposure',
        '19_extended_checks': 'Extended Verification',
    }

    modules = {}
    for module_dir, module_name in module_names.items():
        module_path = os.path.join(scan_dir, module_dir)
        results_file = None
        if os.path.isdir(module_path):
            matches = sorted(glob.glob(os.path.join(module_path, '*_results.json')), key=os.path.getmtime)
            if matches:
                results_file = matches[-1]

        modules[module_dir] = {
            'name': module_name,
            'completed': bool(results_file),
            'data_count': len([f for f in glob.glob(os.path.join(module_path, '*')) if os.path.isfile(f)]) if os.path.isdir(module_path) else 0,
            'data': load_json_file(results_file) if results_file else {}
        }
    return jsonify(modules)


@app.route('/api/vulnerabilities')
def api_vulnerabilities_legacy():
    """Legacy vulnerability endpoint."""
    scan_id = resolve_target(request.args.get('target'))
    logger.info("API request: /api/vulnerabilities target=%s", scan_id)
    data = get_cached_scan_data(scan_id) if scan_id else None
    if not data:
        return jsonify([])
    severity_order = {"critical": 0, "high": 1, "medium": 2, "low": 3, "info": 4}
    vulns = sorted(data.get('vulnerabilities', []), key=lambda x: severity_order.get(x.get('severity', 'info'), 4))
    return jsonify(vulns)


@app.route('/api/risk')
def api_risk_legacy():
    """Legacy risk endpoint."""
    scan_id = resolve_target(request.args.get('target'))
    logger.info("API request: /api/risk target=%s", scan_id)
    if not scan_id:
        return jsonify({})
    data = get_cached_scan_data(scan_id)
    if not data:
        return jsonify({})
    hosts = data.get('hosts', {})
    org_score, grade = compute_org_risk(hosts)
    bands = {'critical': 0, 'high': 0, 'medium': 0, 'low': 0}
    for hd in hosts.values():
        band = hd.get('risk_band', 'low')
        bands[band] = bands.get(band, 0) + 1
    return jsonify({'org_score': org_score, 'grade': grade, 'band_distribution': bands})


@app.route('/api/executive')
def api_executive_legacy():
    """Legacy executive summary endpoint."""
    scan_id = resolve_target(request.args.get('target'))
    logger.info("API request: /api/executive target=%s", scan_id)
    if not scan_id:
        return jsonify({})
    data = get_cached_scan_data(scan_id)
    if not data:
        return jsonify({})
    # Reuse the structured endpoint
    return api_executive(scan_id)


@app.route('/api/cves')
def api_cves_legacy():
    """Legacy CVE endpoint."""
    scan_id = resolve_target(request.args.get('target'))
    logger.info("API request: /api/cves target=%s", scan_id)
    if not scan_id:
        return jsonify([])
    return api_cves(scan_id)


@app.route('/api/manifest')
def api_manifest_legacy():
    """Legacy manifest endpoint."""
    scan_id = resolve_target(request.args.get('target'))
    logger.info("API request: /api/manifest target=%s", scan_id)
    data = get_cached_scan_data(scan_id) if scan_id else None
    return jsonify(data.get('manifest', {}) if data else {})


@app.route('/api/report')
def api_report_legacy():
    """Legacy report endpoint."""
    scan_id = resolve_target(request.args.get('target'))
    logger.info("API request: /api/report target=%s", scan_id)
    if not scan_id:
        return jsonify({})
    report_file = os.path.join(BASE_SCAN_DIR, scan_id, 'reports', 'report.json')
    return jsonify(load_json_file(report_file))

def _host_of_url(url):
    """Best-effort extraction of a hostname from a URL or host:port string."""
    if not url:
        return ''
    try:
        if '//' in url:
            url = url.split('//', 1)[1]
        return url.split('/')[0].split(':')[0]
    except Exception:
        return ''


def build_host_detail(scan_id, host):
    """Aggregate every finding for a single host into a grouped tree.

    Returns the host's metadata plus a list of finding categories, each holding
    the individual findings. This powers the click-through vulnerability report.
    """
    data = get_cached_scan_data(scan_id)
    if not data or not host:
        return {}

    hosts = data.get('hosts', {})
    host_data = hosts.get(host)
    if host_data is None:
        # Fall back to a case-insensitive lookup
        for h, hd in hosts.items():
            if h.lower() == host.lower():
                host, host_data = h, hd
                break
    if host_data is None:
        return {'host': host, 'found': False, 'categories': []}

    # Collect all findings that belong to this host (by host field or URL host)
    host_vulns = []
    for v in data.get('vulnerabilities', []):
        if v.get('host') == host or _host_of_url(v.get('url', '')) == host:
            host_vulns.append(v)

    # Group vulnerabilities by their source into report categories
    source_labels = {
        'Nuclei': 'Vulnerability Findings',
        'Secret Scan': 'Exposed Secrets & Credentials',
        'SQLi Testing': 'SQL Injection',
        'XSS Testing': 'Cross-Site Scripting (XSS)',
        'Param Fuzzing': 'File Inclusion / Path Traversal',
    }
    grouped = {}
    for v in host_vulns:
        src = v.get('source', 'Other')
        grouped.setdefault(src, []).append(v)

    severity_rank = {'critical': 4, 'high': 3, 'medium': 2, 'low': 1, 'info': 0}
    categories = []
    for src, items in grouped.items():
        items.sort(key=lambda x: severity_rank.get(x.get('severity', 'info'), 0), reverse=True)
        top_sev = max((i.get('severity', 'info') for i in items),
                      key=lambda s: severity_rank.get(s, 0), default='info')
        categories.append({
            'key': src,
            'name': source_labels.get(src, src),
            'type': 'vulnerability',
            'count': len(items),
            'max_severity': top_sev,
            'findings': [{
                'title': i.get('template', 'Finding'),
                'severity': i.get('severity', 'info'),
                'url': i.get('url', ''),
                'impact': i.get('impact', ''),
                'remediation': i.get('remediation', ''),
                'cve_id': i.get('cve_id'),
                'source': i.get('source', ''),
            } for i in items]
        })

    # Exposed ports as a category
    ports = sorted(set(int(p) for p in host_data.get('ports_open', [])))
    if ports:
        sensitive = [p for p in ports if p in SENSITIVE_PORTS]
        port_findings = []
        for p in ports:
            is_sensitive = p in SENSITIVE_PORTS
            port_findings.append({
                'title': 'Port ' + str(p) + ' (' + PORT_MAPPINGS.get(p, 'Unknown') + ')',
                'severity': 'high' if is_sensitive else 'info',
                'url': host + ':' + str(p),
                'impact': ('Sensitive service exposed to the internet' if is_sensitive
                           else 'Open port reachable from the internet'),
                'remediation': ('Restrict access via firewall/VPN' if is_sensitive else ''),
                'source': 'Port Scan',
            })
        categories.append({
            'key': 'ports',
            'name': 'Exposed Ports',
            'type': 'infrastructure',
            'count': len(ports),
            'max_severity': 'high' if sensitive else 'info',
            'findings': port_findings,
        })

    # Security header posture as a category
    missing_headers = host_data.get('missing_headers', [])
    if host_data.get('http_status') and missing_headers:
        categories.append({
            'key': 'headers',
            'name': 'Missing Security Headers',
            'type': 'posture',
            'count': len(missing_headers),
            'max_severity': 'medium' if len(missing_headers) >= 4 else 'low',
            'findings': [{
                'title': h,
                'severity': 'low',
                'url': '',
                'impact': 'Security header not set',
                'remediation': 'Add the ' + h + ' response header',
                'source': 'Header Analysis',
            } for h in missing_headers]
        })

    # Discovered directories for this host (from dirsearch output)
    dir_hits = []
    for entry in _load_dirsearch(scan_id):
        if _host_of_url(entry.get('url', '')) == host:
            dir_hits.append(entry)
    if dir_hits:
        dir_hits.sort(key=lambda e: (e.get('status') != 200, e.get('url', '')))
        categories.append({
            'key': 'directories',
            'name': 'Discovered Directories & Files',
            'type': 'discovery',
            'count': len(dir_hits),
            'max_severity': 'medium' if any(e.get('status') == 200 for e in dir_hits) else 'low',
            'findings': [{
                'title': ('[' + str(e.get('status')) + '] ') + e.get('url', ''),
                'severity': 'medium' if e.get('status') == 200 else 'low',
                'url': e.get('url', ''),
                'impact': 'Reachable path (HTTP ' + str(e.get('status')) + ')',
                'remediation': ('Restrict or remove exposed path' if e.get('status') == 200 else ''),
                'source': 'Directory Discovery',
            } for e in dir_hits]
        })

    # Cookie issues
    cookie_issues = host_data.get('cookie_issues', [])
    if cookie_issues:
        categories.append({
            'key': 'cookies',
            'name': 'Cookie Security Issues',
            'type': 'posture',
            'count': len(cookie_issues),
            'max_severity': 'low',
            'findings': [{
                'title': str(c),
                'severity': 'low',
                'url': '',
                'impact': 'Cookie missing a security attribute',
                'remediation': 'Set Secure, HttpOnly and SameSite attributes',
                'source': 'Header Analysis',
            } for c in cookie_issues]
        })

    categories.sort(key=lambda c: severity_rank.get(c.get('max_severity', 'info'), 0), reverse=True)

    severity_counts = {'critical': 0, 'high': 0, 'medium': 0, 'low': 0, 'info': 0}
    for cat in categories:
        for f in cat['findings']:
            s = f.get('severity', 'info')
            severity_counts[s] = severity_counts.get(s, 0) + 1

    return {
        'host': host,
        'found': True,
        'ip': host_data.get('ip', ''),
        'url': host_data.get('url', ''),
        'resolved': host_data.get('resolved', False),
        'http_status': host_data.get('http_status', ''),
        'cdn': host_data.get('cdn', False),
        'waf_vendor': host_data.get('waf_vendor', 'none'),
        'is_api': host_data.get('is_api', False),
        'api_signals': host_data.get('api_signals', []),
        'server_banner': host_data.get('server_banner', ''),
        'security_header_score': host_data.get('security_header_score', 0),
        'ssl_dangling': host_data.get('ssl_dangling', False),
        'ssl_cert_cn': host_data.get('ssl_cert_cn', ''),
        'risk_score': host_data.get('risk_score', 0),
        'risk_band': host_data.get('risk_band', 'low'),
        'ports': ports,
        'total_findings': sum(severity_counts.values()),
        'severity_counts': severity_counts,
        'categories': categories,
    }


@app.route('/api/scan/<scan_id>/host/<path:host>')
def api_host_detail(scan_id, host):
    """Full drill-down report tree for a single host within a scan."""
    detail = build_host_detail(scan_id, host)
    if not detail:
        return jsonify({}), 404
    return jsonify(detail)


@app.route('/api/host')
def api_host_detail_legacy():
    """Host drill-down keyed by ?target=&host=."""
    scan_id = resolve_target(request.args.get('target'))
    host = request.args.get('host', '')
    logger.info("API request: /api/host target=%s host=%s", scan_id, host)
    if not scan_id or not host:
        return jsonify({})
    return jsonify(build_host_detail(scan_id, host))


# ===========================================================================
# AI SECURITY ANALYST
# ===========================================================================

def _gather_ai_context(scan_id):
    """Assemble a compact, structured snapshot of a scan for the AI analyst.

    Pulls from the same loaders the dashboard tabs use so the model sees exactly
    what the operator sees — risk score, exposure, prioritized findings across
    vulns / cloud / API / CVEs — capped so the prompt stays token-bounded.
    """
    data = get_cached_scan_data(scan_id)
    if not data:
        return None

    hosts = data.get('hosts', {})
    vulns = data.get('vulnerabilities', [])
    org_score, grade = compute_org_risk(hosts)
    target = data.get('pipeline_info', {}).get('target', scan_id)

    sev_counts = {'critical': 0, 'high': 0, 'medium': 0, 'low': 0, 'info': 0}
    for v in vulns:
        s = v.get('severity', 'info')
        sev_counts[s] = sev_counts.get(s, 0) + 1

    def _sev_rank(v):
        return {'critical': 4, 'high': 3, 'medium': 2, 'low': 1, 'info': 0}.get(v.get('severity', 'info'), 0)

    def _slim(v):
        return {
            'title': v.get('template') or v.get('name') or v.get('issue_class') or 'finding',
            'severity': v.get('severity', 'info'),
            'source': v.get('source', ''),
            'host': v.get('host', ''),
            'url': v.get('url', ''),
            'impact': (v.get('impact') or '')[:240],
        }

    # App/infra vulns (exclude cloud + API, which are summarized separately).
    app_vulns = [v for v in vulns if v.get('source') not in ('Cloud Exposure',)]
    app_vulns.sort(key=lambda v: (_sev_rank(v), v.get('weighted_score', 0)), reverse=True)
    top_vulns = [_slim(v) for v in app_vulns[:25]]

    # Cloud findings (whitelist-scoped, same as the Cloud tab).
    cloud = [v for v in vulns
             if v.get('source') == 'Cloud Exposure'
             and v.get('cloud_category') in CLOUD_ALL_CATEGORIES]
    cloud.sort(key=lambda v: v.get('weighted_score', 0), reverse=True)
    cloud_findings = [{
        'category': v.get('cloud_category', ''),
        'title': v.get('template', ''),
        'severity': v.get('severity', 'info'),
        'host': v.get('host', ''),
        'impact': (v.get('impact') or '')[:240],
    } for v in cloud[:20]]

    # API security findings.
    api_findings = _load_api_security_findings(scan_id)
    api_slim = [{
        'endpoint': f.get('endpoint') or f"{f.get('method', '')} {f.get('path', '')}".strip(),
        'issue': f.get('issue_class', ''),
        'severity': f.get('severity', 'info'),
        'tools': f.get('tools') or ([f.get('tool')] if f.get('tool') else []),
    } for f in sorted(api_findings, key=lambda x: _sev_rank(x), reverse=True)[:20]]

    # CVEs harvested from nuclei findings.
    cve_re = re.compile(r'CVE-\d{4}-\d{4,7}', re.IGNORECASE)
    cves = {}
    for v in vulns:
        blob = f"{v.get('template', '')} {v.get('name', '')} {v.get('cve', '')}"
        for m in cve_re.findall(blob):
            cid = m.upper()
            cves.setdefault(cid, {'cve': cid, 'severity': v.get('severity', 'info'), 'host': v.get('host', '')})

    # Sensitive exposed services.
    sensitive = []
    for host, hd in hosts.items():
        for p in set(hd.get('ports_open', [])) & SENSITIVE_PORTS:
            sensitive.append({'host': host, 'port': p, 'service': PORT_MAPPINGS.get(p, 'Unknown')})

    secrets_count = sum(1 for v in vulns if v.get('source') == 'Secret Scan')
    http_hosts = sum(1 for h in hosts.values() if h.get('http_status'))
    waf_uncovered = sum(1 for h in hosts.values()
                        if h.get('http_status') and h.get('waf_vendor') in ('none', '', None))

    return {
        'target': target,
        'scan_id': scan_id,
        'risk_score': org_score,
        'grade': grade,
        'assets': {
            'total_hosts': len(hosts),
            'internet_facing_http': http_hosts,
            'waf_uncovered': waf_uncovered,
            'cdn_fronted': sum(1 for h in hosts.values() if h.get('cdn')),
        },
        'severity_counts': sev_counts,
        'secrets_found': secrets_count,
        'sensitive_services': sensitive[:20],
        'top_vulnerabilities': top_vulns,
        'cloud_findings': cloud_findings,
        'api_findings': api_slim,
        'cves': list(cves.values())[:30],
    }


# Base analyst persona shared by every preset. The concrete output shape comes
# from the per-preset instruction appended to the user message.
AI_SYSTEM_PROMPT = (
    "You are ARISE's security analyst. You receive a JSON snapshot of an External "
    "Attack Surface Monitoring scan (risk score, exposed assets, and prioritized "
    "findings across web vulnerabilities, cloud misconfigurations, API security, and "
    "CVEs) and write clear, decision-ready output in GitHub-flavored Markdown. "
    "Ground every claim in the provided data — never invent findings, hosts, or CVEs. "
    "If the data is thin, say so plainly. Be direct and specific; avoid filler and "
    "vendor-speak."
)

# System prompt for the folder-review mode (analyzing raw scan output files).
AI_FOLDER_SYSTEM_PROMPT = (
    "You are ARISE's security analyst reviewing raw scan output files. Read the files "
    "provided and produce a clear, decision-ready security review in GitHub-flavored "
    "Markdown. Ground every claim in the file contents and reference the specific file "
    "a finding came from. Never invent results. Call out secrets, misconfigurations, "
    "exposed services, and high-signal findings; note what is inconclusive."
)

# Default analysis commands. 'executive' is the default; the operator can pick any,
# but a custom prompt or a folder target overrides the preset entirely.
AI_PRESETS = {
    'executive': {
        'label': 'Executive Briefing',
        'instruction': (
            "Produce the security briefing with these sections: **Executive Summary** "
            "(2-3 sentences, readable by a non-technical CXO), **Top Risks** (ranked 3-6, "
            "each with concrete business impact and the affected asset), **Recommended "
            "Actions** (prioritized P0/P1/P2), and **Positive Signals** (what's being done "
            "well). Keep the whole briefing under ~450 words."
        ),
    },
    'remediation': {
        'label': 'Remediation Plan',
        'instruction': (
            "Produce a prioritized remediation plan. For each issue give: title, severity, "
            "affected asset(s), concrete fix steps, a suggested owning team (Platform / "
            "AppSec / Cloud / Network), and rough effort (S/M/L). Order by risk reduced per "
            "unit of effort. End with a **Do this week** shortlist of 3-5 items."
        ),
    },
    'attack_paths': {
        'label': 'Attack Path Analysis',
        'instruction': (
            "Think like an attacker. Identify the 2-4 most plausible attack chains that link "
            "these findings into a real breach (initial access -> pivot -> impact). For each "
            "chain: the steps, the specific hosts/findings involved, and the single control "
            "that would break the chain. Only use findings present in the data."
        ),
    },
    'compliance': {
        'label': 'Compliance & Hardening Gaps',
        'instruction': (
            "Map the findings to common control expectations (OWASP Web/API Top 10, CIS-style "
            "cloud hardening, TLS and email-auth hygiene). List gaps as: control area, what's "
            "failing, the evidence from the data, and the remediation. Note where the data is "
            "insufficient to judge a control."
        ),
    },
    'triage': {
        'label': 'Quick Triage',
        'instruction': (
            "Fast triage in under 200 words: the single biggest risk right now, the top 3 "
            "things to verify or fix today, and one thing that looks fine. Bullet points, no "
            "preamble."
        ),
    },
}

# Supported AI providers. Claude uses the Anthropic SDK; the others are called over
# their HTTPS APIs (OpenAI-compatible chat for OpenAI/Hugging Face, generateContent
# for Gemini). Keys resolve from the request first, then any of the listed env vars.
AI_PROVIDERS = {
    'claude': {
        'label': 'Claude (Anthropic)',
        'default_model': AI_MODEL,
        'env_names': ['ANTHROPIC_API_KEY', 'ANTHROPIC_AUTH_TOKEN'],
    },
    'openai': {
        'label': 'OpenAI',
        'default_model': os.environ.get('OPENAI_MODEL', 'gpt-4o'),
        'env_names': ['OPENAI_API_KEY'],
    },
    'gemini': {
        'label': 'Google Gemini',
        'default_model': os.environ.get('GEMINI_MODEL', 'gemini-1.5-flash'),
        'env_names': ['GEMINI_API_KEY', 'GOOGLE_API_KEY'],
    },
    'huggingface': {
        'label': 'Hugging Face',
        'default_model': os.environ.get('HF_MODEL', 'meta-llama/Llama-3.1-8B-Instruct'),
        'env_names': ['HF_API_TOKEN', 'HUGGINGFACE_API_KEY', 'HUGGINGFACEHUB_API_TOKEN'],
    },
}


def _provider_key(provider, supplied=None):
    """Resolve an API key for a provider: request-supplied first, then env vars."""
    if supplied and supplied.strip():
        return supplied.strip()
    for env in AI_PROVIDERS.get(provider, {}).get('env_names', []):
        val = os.environ.get(env)
        if val:
            return val
    return ''


def _gather_folder_context(folder, scan_id=None):
    """Read text files from a scan output folder for the folder-review mode.

    Sandboxed to the scans directory (path traversal is rejected). Relative paths
    resolve against the current scan first, then the scans root.
    """
    base = os.path.realpath(BASE_SCAN_DIR)
    candidates = []
    if scan_id:
        candidates.append(os.path.join(BASE_SCAN_DIR, scan_id, folder))
    candidates.append(os.path.join(BASE_SCAN_DIR, folder))
    candidates.append(folder)

    target = None
    for cand in candidates:
        rp = os.path.realpath(cand)
        if os.path.isdir(rp) and (rp == base or rp.startswith(base + os.sep)):
            target = rp
            break
    if not target:
        return None, ("Folder not found or outside the scans directory. Use a path like "
                      "'<scan-id>/16_api_security' or a module folder within the current scan.")

    exts = {'.json', '.jsonl', '.txt', '.md', '.csv', '.log', '.yaml', '.yml'}
    PER_FILE, TOTAL_CAP, MAX_FILES = 20000, 200000, 40
    files, total = [], 0
    for root, _dirs, fnames in os.walk(target):
        for fn in sorted(fnames):
            if len(files) >= MAX_FILES or total >= TOTAL_CAP:
                break
            if os.path.splitext(fn)[1].lower() not in exts:
                continue
            fp = os.path.join(root, fn)
            try:
                with open(fp, errors='ignore') as fh:
                    content = fh.read(PER_FILE)
            except Exception:
                continue
            files.append({'path': os.path.relpath(fp, target), 'content': content})
            total += len(content)
    if not files:
        return None, "No readable text files (json/jsonl/txt/log/csv/yaml) found in that folder."
    return {
        'folder': os.path.relpath(target, base),
        'file_count': len(files),
        'files': files,
        'truncated': total >= TOTAL_CAP,
    }, None


def _call_claude(model, api_key, system, user):
    try:
        import anthropic
    except ImportError:
        return None, ("The 'anthropic' package is not installed. Run "
                      "`pip install anthropic` to use the Claude provider.")
    try:
        client = anthropic.Anthropic(api_key=api_key) if api_key else anthropic.Anthropic()
        # Server-side streaming guards against HTTP timeouts on longer generations.
        with client.messages.stream(
            model=model,
            max_tokens=4000,
            system=system,
            thinking={"type": "adaptive"},
            output_config={"effort": "medium"},
            messages=[{"role": "user", "content": user}],
        ) as stream:
            final = stream.get_final_message()
        if final.stop_reason == 'refusal':
            return None, "The model declined to analyze this content."
        text = "".join(b.text for b in final.content if getattr(b, 'type', None) == 'text').strip()
        return (text or "The model returned an empty response."), None
    except anthropic.AuthenticationError:
        return None, "Anthropic authentication failed. Set a valid ANTHROPIC_API_KEY in .env and restart."
    except anthropic.APIStatusError as exc:
        return None, f"Anthropic API error ({exc.status_code}): {getattr(exc, 'message', str(exc))}"
    except Exception as exc:  # noqa: BLE001
        msg = str(exc)
        if 'authentication method' in msg or 'api_key' in msg:
            return None, "No Anthropic credentials found. Set ANTHROPIC_API_KEY in .env and restart the dashboard."
        logger.error("Claude call failed: %s", exc)
        return None, f"Claude call failed: {exc}"


def _call_openai_chat(url, model, api_key, system, user, provider_label):
    """OpenAI-compatible chat completions (used for OpenAI and the Hugging Face router)."""
    if not api_key:
        return None, f"No API key for {provider_label}. Set its API key in .env and restart the dashboard."
    import requests as _requests
    try:
        resp = _requests.post(
            url,
            headers={'Authorization': f'Bearer {api_key}', 'Content-Type': 'application/json'},
            json={
                'model': model,
                'messages': [
                    {'role': 'system', 'content': system},
                    {'role': 'user', 'content': user},
                ],
                'max_tokens': 1800,
                'temperature': 0.3,
            },
            timeout=120,
        )
    except Exception as exc:  # noqa: BLE001
        return None, f"{provider_label} request failed: {exc}"
    if resp.status_code // 100 != 2:
        return None, f"{provider_label} API error ({resp.status_code}): {resp.text[:200]}"
    try:
        data = resp.json()
        text = (data['choices'][0]['message']['content'] or '').strip()
    except Exception:
        return None, f"{provider_label} returned an unexpected response."
    return (text or "The model returned an empty response."), None


def _call_gemini(model, api_key, system, user):
    if not api_key:
        return None, "No API key for Google Gemini. Set GEMINI_API_KEY in .env and restart the dashboard."
    import requests as _requests
    url = (f"https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent"
           f"?key={api_key}")
    try:
        resp = _requests.post(
            url,
            json={
                'system_instruction': {'parts': [{'text': system}]},
                'contents': [{'role': 'user', 'parts': [{'text': user}]}],
                'generationConfig': {'maxOutputTokens': 2048, 'temperature': 0.3},
            },
            timeout=120,
        )
    except Exception as exc:  # noqa: BLE001
        return None, f"Gemini request failed: {exc}"
    if resp.status_code // 100 != 2:
        return None, f"Gemini API error ({resp.status_code}): {resp.text[:200]}"
    try:
        data = resp.json()
        cands = data.get('candidates') or []
        if not cands:
            reason = (data.get('promptFeedback') or {}).get('blockReason', 'no candidates')
            return None, f"Gemini returned no content ({reason})."
        parts = cands[0].get('content', {}).get('parts', [])
        text = "".join(p.get('text', '') for p in parts).strip()
    except Exception:
        return None, "Gemini returned an unexpected response."
    return (text or "The model returned an empty response."), None


def _run_ai_provider(provider, model, api_key, system, user):
    """Dispatch a completion to the selected provider. Returns (markdown_text, error)."""
    if provider == 'claude':
        return _call_claude(model, api_key, system, user)
    if provider == 'openai':
        return _call_openai_chat('https://api.openai.com/v1/chat/completions',
                                 model, api_key, system, user, 'OpenAI')
    if provider == 'huggingface':
        return _call_openai_chat('https://router.huggingface.co/v1/chat/completions',
                                 model, api_key, system, user, 'Hugging Face')
    if provider == 'gemini':
        return _call_gemini(model, api_key, system, user)
    return None, f"Unknown provider: {provider}"


def _markdown_to_slack(md):
    """Convert the briefing's GitHub Markdown into Slack mrkdwn.

    Slack uses *bold* / _italic_ and has no heading syntax, so headings become
    bold lines and `**bold**` collapses to `*bold*`.
    """
    lines = []
    for raw in md.splitlines():
        line = raw.rstrip()
        m = re.match(r'^(#{1,6})\s+(.*)$', line)
        if m:
            lines.append(f"*{m.group(2).strip()}*")
            continue
        # **bold** -> *bold*
        line = re.sub(r'\*\*(.+?)\*\*', r'*\1*', line)
        # markdown bullets -> slack bullets
        line = re.sub(r'^\s*[-*]\s+', '• ', line)
        lines.append(line)
    return "\n".join(lines)


# ---------------------------------------------------------------------------
# Global settings (provider / model / auto-Slack), persisted to a JSON file.
# ---------------------------------------------------------------------------
def _default_ready_provider():
    for pid in AI_PROVIDERS:
        if _provider_key(pid, None):
            return pid
    return 'claude'


def load_settings():
    """Effective settings: file overrides .env defaults override built-ins."""
    data = {}
    try:
        with open(SETTINGS_FILE) as fh:
            data = json.load(fh) or {}
    except Exception:
        data = {}
    provider = (data.get('provider') or AI_PROVIDER_ENV or _default_ready_provider())
    if provider not in AI_PROVIDERS:
        provider = 'claude'
    return {
        'provider': provider,
        'model': (data.get('model') or '').strip(),
        'auto_slack': bool(data.get('auto_slack', AUTO_SLACK_DEFAULT)),
    }


def save_settings(patch):
    settings = load_settings()
    if 'provider' in patch and patch['provider'] in AI_PROVIDERS:
        settings['provider'] = patch['provider']
    if 'model' in patch:
        settings['model'] = (patch.get('model') or '').strip()
    if 'auto_slack' in patch:
        settings['auto_slack'] = bool(patch['auto_slack'])
    try:
        with open(SETTINGS_FILE, 'w') as fh:
            json.dump(settings, fh, indent=2)
    except Exception as exc:
        logger.error("Failed to write settings: %s", exc)
    return settings


# ---------------------------------------------------------------------------
# Secret masking — never leak API keys or webhooks into Slack/logs.
# ---------------------------------------------------------------------------
_SECRET_RE = re.compile(
    r'(https://hooks\.slack\.com/services/[A-Za-z0-9/_+-]+'
    r'|sk-[A-Za-z0-9_\-]{6,}'
    r'|ghp_[A-Za-z0-9]{6,}'
    r'|AIza[A-Za-z0-9_\-]{10,}'
    r'|hf_[A-Za-z0-9]{6,}'
    r'|xox[baprs]-[A-Za-z0-9-]{6,})'
)


def _mask_token(tok):
    if tok.startswith('https://hooks.slack.com/'):
        return 'https://hooks.slack.com/services/****'
    if len(tok) > 8:
        return tok[:4] + '…' + tok[-4:]
    return '****'


def _mask_secrets(text):
    """Redact any API key / Slack webhook that may appear in a string."""
    return _SECRET_RE.sub(lambda m: _mask_token(m.group(0)), text or '')


def _post_slack(webhook, text):
    """Post a message to a Slack Incoming Webhook. Returns (ok, error)."""
    if not (webhook or '').startswith('https://hooks.slack.com/'):
        return False, ("No valid Slack Incoming Webhook. Set SLACK_WEBHOOK_URL in .env "
                       "or paste a webhook URL.")
    try:
        import requests as _requests
        resp = _requests.post(webhook, json={'text': _mask_secrets(text)}, timeout=15)
    except Exception as exc:  # noqa: BLE001
        logger.error("Slack push failed: %s", exc)
        return False, f"Slack push failed: {exc}"
    if resp.status_code // 100 != 2:
        return False, f"Slack returned {resp.status_code}: {resp.text[:200]}"
    return True, None


# ---------------------------------------------------------------------------
# Automated post-scan AI review -> Slack.
# ---------------------------------------------------------------------------
AI_REVIEW_SYSTEM_PROMPT = (
    "You are ARISE's senior security analyst writing a short review of a completed "
    "External Attack Surface scan, the way an experienced human reviewer would in a "
    "Slack update to the security team. Read the JSON snapshot and write in "
    "GitHub-flavored Markdown, warm but precise, first-person where natural.\n\n"
    "Structure:\n"
    "1. **Overall** — 2-3 sentences: your read on the posture and the one thing that "
    "matters most right now.\n"
    "2. **What stood out** — 3-5 bullets, each naming the issue, why it matters in "
    "practice, and the affected asset.\n"
    "3. **What I'd do next** — 2-4 prioritized actions.\n\n"
    "Ground every claim in the data — never invent findings, hosts, or CVEs. If the "
    "data is thin, say so. Keep it under ~300 words."
)


def _cve_link(cve):
    return f"https://nvd.nist.gov/vuln/detail/{cve}"


def _build_slack_summary(context, review_md, provider, model, scan_id):
    """Compose the rich Slack message for an automated post-scan review."""
    sev = context.get('severity_counts', {})
    score = context.get('risk_score', 0)
    grade = context.get('grade', '?')
    target = context.get('target', scan_id)

    # Severity emoji for the headline.
    if sev.get('critical'):
        head_icon = ':rotating_light:'
    elif sev.get('high'):
        head_icon = ':red_circle:'
    elif sev.get('medium'):
        head_icon = ':large_yellow_circle:'
    else:
        head_icon = ':large_green_circle:'

    lines = [f"{head_icon} *ARISE scan complete — {target}*"]
    lines.append(
        f"*Overall vulnerability score:* {grade} · {score}/100    "
        f"C:{sev.get('critical',0)}  H:{sev.get('high',0)}  M:{sev.get('medium',0)}  "
        f"L:{sev.get('low',0)}    Assets: {context.get('assets',{}).get('total_hosts',0)}"
    )
    lines.append("")
    lines.append(_markdown_to_slack(review_md))

    # Top issues with reference URLs (affected asset link).
    issues = (context.get('top_vulnerabilities') or [])[:6]
    cloud = (context.get('cloud_findings') or [])[:4]
    if issues or cloud:
        lines.append("")
        lines.append("*Top issues*")
        for v in issues:
            ref = v.get('url') or v.get('host') or ''
            ref = f"  <{ref}>" if ref.startswith('http') else (f"  `{ref}`" if ref else '')
            lines.append(f"• [{v.get('severity','info').upper()}] {v.get('title','finding')}{ref}")
        for c in cloud:
            lines.append(f"• [{c.get('severity','info').upper()}] {c.get('title','')} — `{c.get('host','')}`")

    # Reference URLs (CVEs + distinct affected hosts).
    refs = []
    for cve in (context.get('cves') or [])[:8]:
        refs.append(_cve_link(cve.get('cve', '')))
    seen = set()
    for v in issues:
        u = v.get('url') or ''
        if u.startswith('http') and u not in seen:
            seen.add(u)
            refs.append(u)
        if len(refs) >= 12:
            break
    if refs:
        lines.append("")
        lines.append("*References*")
        for r in refs[:12]:
            lines.append(f"• {r}")

    # Trace line — provider/model + the key used, masked.
    key = _provider_key(provider, None)
    key_disp = _mask_token(key) if key else 'none'
    lines.append("")
    lines.append(
        f"_Trace — scan `{scan_id}` · engine {provider}/{model} · "
        f"key {key_disp} · {datetime.now().isoformat(timespec='seconds')}_"
    )
    return "\n".join(lines)


def _scan_status(scan_id):
    """Return the pipeline status string for a scan, or '' if unreadable."""
    try:
        with open(os.path.join(BASE_SCAN_DIR, scan_id, 'manifest.json')) as fh:
            return (json.load(fh).get('pipeline_info', {}) or {}).get('status', '')
    except Exception:
        return ''


def _auto_summarize_scan(scan_id, force=False):
    """Generate an AI review of a completed scan and post it to Slack.

    Idempotent: writes a marker file so a scan is summarized at most once unless
    forced. Returns (ok, message).
    """
    marker = os.path.join(BASE_SCAN_DIR, scan_id, '.ai_summary_posted')
    settings = load_settings()

    if not force and not settings['auto_slack']:
        return False, "Automated Slack summary is disabled."

    provider = settings['provider']
    model = settings['model'] or AI_PROVIDERS[provider]['default_model']
    api_key = _provider_key(provider, None)
    webhook = SLACK_WEBHOOK_URL

    # If we can't post, mark as handled (so re-enabling later doesn't flood old scans).
    if not api_key or not webhook.startswith('https://hooks.slack.com/'):
        if not force:
            _write_marker(marker, 'skipped: missing provider key or Slack webhook')
        return False, "Missing provider API key or Slack webhook (.env)."

    context = _gather_ai_context(scan_id)
    if context is None:
        return False, "Scan data not found."

    user = ("Here is the completed scan snapshot as JSON:\n\n```json\n"
            + json.dumps(context, indent=2, default=str) + "\n```\n\n"
            + "Write your review.")
    review, error = _run_ai_provider(provider, model, api_key, AI_REVIEW_SYSTEM_PROMPT, user)
    if error:
        logger.warning("Auto-summary AI call failed for %s: %s", scan_id, error)
        return False, error

    body = _build_slack_summary(context, review, provider, model, scan_id)
    ok, serr = _post_slack(webhook, body)
    if ok:
        _write_marker(marker, f"posted via {provider}/{model}")
        logger.info("Auto-summary posted to Slack for %s", scan_id)
        return True, "Posted to Slack."
    logger.warning("Auto-summary Slack post failed for %s: %s", scan_id, serr)
    return False, serr


def _write_marker(path, note):
    try:
        with open(path, 'w') as fh:
            fh.write(f"{datetime.now().isoformat(timespec='seconds')} {note}\n")
    except Exception as exc:
        logger.error("Failed to write marker %s: %s", path, exc)


def _ai_watcher_loop():
    """Background thread: post an AI Slack summary when a scan newly completes.

    On the first pass it baselines every already-completed scan (writes the marker
    without posting) so restarting the dashboard never floods the backlog. After
    that, any scan that reaches 'completed' without a marker gets summarized.
    """
    baseline_done = False
    logger.info("AI scan watcher started (interval %ss)", AI_WATCH_INTERVAL)
    while True:
        try:
            for scan in get_available_scans(use_cache=False):
                sid = scan.get('id')
                status = scan.get('status', '')
                if status not in ('completed', 'completed_with_errors'):
                    continue
                marker = os.path.join(BASE_SCAN_DIR, sid, '.ai_summary_posted')
                if os.path.exists(marker):
                    continue
                if not baseline_done:
                    _write_marker(marker, 'baseline (existing scan at dashboard start)')
                    continue
                _auto_summarize_scan(sid)
            baseline_done = True
        except Exception as exc:  # noqa: BLE001
            logger.error("AI watcher error: %s", exc)
        time.sleep(AI_WATCH_INTERVAL)


def start_ai_watcher():
    t = threading.Thread(target=_ai_watcher_loop, name='ai-watcher', daemon=True)
    t.start()
    return t


@app.route('/api/settings', methods=['GET', 'POST'])
def api_settings():
    """Read or update the global AI settings (provider / model / auto-Slack)."""
    if request.method == 'POST':
        save_settings(request.get_json(silent=True) or {})
    settings = load_settings()
    prov = AI_PROVIDERS[settings['provider']]
    return jsonify({
        'provider': settings['provider'],
        'provider_label': prov['label'],
        'model': settings['model'],
        'effective_model': settings['model'] or prov['default_model'],
        'auto_slack': settings['auto_slack'],
        'provider_ready': bool(_provider_key(settings['provider'], None)),
        'slack_configured': bool(SLACK_WEBHOOK_URL),
        'providers': [
            {'id': pid, 'label': p['label'], 'default_model': p['default_model'],
             'ready': bool(_provider_key(pid, None))}
            for pid, p in AI_PROVIDERS.items()
        ],
    })


@app.route('/api/ai/slack-test', methods=['POST'])
def api_ai_slack_test():
    """Send a test message to the configured Slack webhook."""
    ok, err = _post_slack(SLACK_WEBHOOK_URL,
                          ":white_check_mark: *ARISE* — Slack integration test. "
                          "Automated scan summaries will arrive here.")
    if ok:
        return jsonify({'ok': True})
    return jsonify({'error': err}), 400


@app.route('/api/ai/auto-summary/<path:scan_id>', methods=['POST'])
def api_ai_auto_summary(scan_id):
    """Force-generate and post an AI summary for a scan (used by the UI 'resend')."""
    resolved = resolve_target(scan_id) or scan_id
    ok, msg = _auto_summarize_scan(resolved, force=True)
    if ok:
        return jsonify({'ok': True, 'message': msg})
    return jsonify({'error': msg}), 502


@app.route('/api/ai/analyze', methods=['POST'])
def api_ai_analyze():
    """Generate an AI security analysis with the selected provider.

    Precedence: a target **folder** or a **custom prompt** overrides the default
    analysis command (preset). Folder wins over custom prompt when both are given.
    """
    payload = request.get_json(silent=True) or {}
    scan_id = resolve_target(payload.get('target') or request.args.get('target'))

    # Provider/model come from the global Settings unless the request overrides them.
    settings = load_settings()
    provider = (payload.get('provider') or settings['provider']).strip()
    if provider not in AI_PROVIDERS:
        return jsonify({'error': f'Unknown provider: {provider}'}), 400
    model = ((payload.get('model') or '').strip()
             or (settings['model'] if provider == settings['provider'] else '')
             or AI_PROVIDERS[provider]['default_model'])
    api_key = _provider_key(provider, payload.get('api_key'))
    question = (payload.get('question') or '').strip()
    folder = (payload.get('folder') or '').strip()
    preset = (payload.get('preset') or 'executive').strip()
    logger.info("API request: /api/ai/analyze provider=%s target=%s mode=%s",
                provider, scan_id, 'folder' if folder else ('custom' if question else preset))

    risk_score = grade = target_name = None
    mode = None

    if folder:
        # Folder review — the default preset is ignored.
        fctx, ferr = _gather_folder_context(folder, scan_id)
        if ferr:
            return jsonify({'error': ferr}), 400
        system = AI_FOLDER_SYSTEM_PROMPT
        instruction = question or ("Review these files for security issues, misconfigurations, "
                                   "exposed secrets, and notable findings, then summarize what "
                                   "matters and what to do about it.")
        user = ("Here are the files from folder `" + fctx['folder'] + "`"
                + (" (truncated)" if fctx['truncated'] else "") + ":\n\n```json\n"
                + json.dumps(fctx['files'], indent=2, default=str) + "\n```\n\n" + instruction)
        target_name = fctx['folder']
        mode = 'folder'
    else:
        if not scan_id:
            return jsonify({'error': 'No scan selected.'}), 400
        context = _gather_ai_context(scan_id)
        if context is None:
            return jsonify({'error': 'Scan data not found.'}), 404
        risk_score, grade, target_name = context['risk_score'], context['grade'], context['target']
        snapshot = ("Here is the scan snapshot as JSON:\n\n```json\n"
                    + json.dumps(context, indent=2, default=str) + "\n```\n\n")
        system = AI_SYSTEM_PROMPT
        if question:
            # Custom prompt — the default preset is ignored.
            user = snapshot + "The operator asked, answer it directly using the data above:\n\n" + question
            mode = 'custom'
        else:
            p = AI_PRESETS.get(preset, AI_PRESETS['executive'])
            user = snapshot + p['instruction']
            mode = 'preset:' + (preset if preset in AI_PRESETS else 'executive')

    analysis, error = _run_ai_provider(provider, model, api_key, system, user)
    if error:
        return jsonify({'error': error}), 502
    return jsonify({
        'target': target_name,
        'scan_id': scan_id,
        'provider': provider,
        'provider_label': AI_PROVIDERS[provider]['label'],
        'model': model,
        'mode': mode,
        'risk_score': risk_score,
        'grade': grade,
        'analysis': analysis,
        'generated_at': datetime.now().isoformat(timespec='seconds'),
    })


@app.route('/api/ai/slack', methods=['POST'])
def api_ai_slack():
    """Push a manual analysis to Slack via the configured Incoming Webhook (.env)."""
    payload = request.get_json(silent=True) or {}
    text = (payload.get('text') or '').strip()
    target = payload.get('target') or ''
    if not text:
        return jsonify({'error': 'Nothing to send — generate an analysis first.'}), 400

    header = f":shield: *ARISE Security Briefing — {target}*" if target else ":shield: *ARISE Security Briefing*"
    body = f"{header}\n\n{_markdown_to_slack(text)}"
    ok, err = _post_slack(SLACK_WEBHOOK_URL, body)
    if ok:
        return jsonify({'ok': True})
    return jsonify({'error': err}), 502


@app.route('/api/ai/status')
def api_ai_status():
    """Report available providers, presets, and Slack config so the UI can guide setup."""
    try:
        import anthropic  # noqa: F401
        claude_installed = True
    except ImportError:
        claude_installed = False

    providers = []
    default_provider = None
    for pid, p in AI_PROVIDERS.items():
        installed = claude_installed if pid == 'claude' else True  # others just need requests
        key_set = bool(_provider_key(pid, None))
        ready = installed and key_set
        if ready and default_provider is None:
            default_provider = pid
        providers.append({
            'id': pid, 'label': p['label'], 'default_model': p['default_model'],
            'installed': installed, 'key_set': key_set, 'ready': ready,
        })
    presets = [{'id': k, 'label': v['label']} for k, v in AI_PRESETS.items()]
    return jsonify({
        'providers': providers,
        'presets': presets,
        'default_provider': default_provider or 'claude',
        'any_ready': any(p['ready'] for p in providers),
        'slack_env_configured': bool(SLACK_WEBHOOK_URL),
    })


# ===========================================================================
# MAIN
# ===========================================================================

if __name__ == '__main__':
    print("=" * 70)
    print("   ARISE Dashboard v3.0 - Summon Every Hidden Exposure.")
    print("=" * 70)
    print()
    
    os.makedirs('templates', exist_ok=True)
    
    if not os.path.exists(BASE_SCAN_DIR):
        os.makedirs(BASE_SCAN_DIR, exist_ok=True)
        print(f"[*] Created scans directory: {BASE_SCAN_DIR}")
    
    scans = get_available_scans()
    print(f"[*] Found {len(scans)} completed scans")
    
    if scans:
        print("\n[+] Available scans:")
        for scan in scans[:5]:
            print(f"    - {scan['name']} ({scan['id']})")
            print(f"      Hosts: {scan['total_hosts']} | HTTP: {scan['http_hosts']} | Ports: {scan['total_ports']}")
    
    _port = int(os.environ.get('ARISE_DASHBOARD_PORT', 5000))

    print()
    print("Dashboard running at:")
    print(f"  http://localhost:{_port}")
    print()
    print("Press Ctrl+C to stop")
    print()

    # Watch for newly completed scans and auto-post AI summaries to Slack.
    _settings = load_settings()
    print(f"[*] AI: provider={_settings['provider']} | auto-Slack={'on' if _settings['auto_slack'] else 'off'} "
          f"| Slack webhook={'set' if SLACK_WEBHOOK_URL else 'unset'}")
    start_ai_watcher()

    app.run(host='0.0.0.0', port=_port, debug=True, use_reloader=False)
