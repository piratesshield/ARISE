#!/usr/bin/env python3
"""
KAIJU Correlation Engine — Issues, rules, state, timeline.

INV-1: Issue refs are stable across revisions (derived from rule_id + primary_asset + discriminator).
INV-2: Computed half (evidence/severity/risk) is always recomputed; stored half
       (status/first_seen/detections/history) lives in issues-state.json and is never
       overwritten by computation.  Orphaned state entries are tombstoned, never deleted.

Atomic writes: issues-state.json is written via temp+os.rename with a .bak copy.
events.jsonl appends are idempotent on (rev_from, rev_to, kind, ref).
"""

import hashlib
import json
import os
import shutil
import tempfile
import logging
from datetime import datetime

import kaiju_entities as ke

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Issue ref (INV-1)
# ---------------------------------------------------------------------------

def _issue_ref(rule_id, primary_ref, discriminator=''):
    """Stable issue ref = hash(rule_id:primary_ref:discriminator)."""
    key = f"{rule_id}:{primary_ref}:{discriminator}"
    digest = hashlib.sha1(key.encode('utf-8')).hexdigest()[:12]
    return f"issue:{digest}"


# ---------------------------------------------------------------------------
# Correlation rules — each returns a list of computed issues
# ---------------------------------------------------------------------------

# Sensitive ports — DB, cache, message queue (shouldn't be public)
SENSITIVE_PORTS = {
    3306: 'MySQL', 5432: 'PostgreSQL', 6379: 'Redis', 27017: 'MongoDB',
    1433: 'MSSQL', 9200: 'Elasticsearch', 5601: 'Kibana', 11211: 'Memcached',
    9042: 'Cassandra', 2181: 'ZooKeeper',
}

# Management / remote-access ports
MGMT_PORTS = {22: 'SSH', 23: 'Telnet', 3389: 'RDP', 5900: 'VNC', 8080: 'HTTP-Alt', 9090: 'Management'}

# Dev/staging hostname patterns
DEV_PATTERNS = ['dev', 'staging', 'stage', 'test', 'uat', 'qa', 'sandbox', 'demo', 'beta', 'alpha', 'preprod', 'internal']


def _sev_color(sev):
    return {'critical': '#f87171', 'high': '#f97316', 'medium': '#eab308', 'low': '#38bdf8', 'info': '#94a3b8'}.get(sev, '#94a3b8')


def rule_exposed_service(entities, relations):
    """Sensitive database/cache ports exposed to the internet."""
    issues = []
    for e in entities:
        if e['type'] != 'svc':
            continue
        port = e['attrs'].get('port')
        if port not in SENSITIVE_PORTS:
            continue
        product = SENSITIVE_PORTS[port]
        svc_product = e['attrs'].get('product', '')

        # Find the host running this service
        host_refs = [r['source'] for r in relations if r['target'] == e['ref'] and r['type'] == 'RUNS']
        for hr in host_refs:
            host_e = ke.entity_by_ref(entities, hr)
            if not host_e:
                continue

            # Find subs pointing to this host
            sub_refs = [r['source'] for r in relations if r['target'] == hr and r['type'] == 'RESOLVES_TO']
            sub_labels = []
            for sr in sub_refs:
                se = ke.entity_by_ref(entities, sr)
                if se:
                    sub_labels.append(se['label'])

            chain = sub_refs[:1] + [hr, e['ref']]
            issues.append({
                'ref': _issue_ref('exposed-service', hr, str(port)),
                'rule_id': 'exposed-service',
                'title': f"Publicly exposed {product} (port {port}) on {host_e['label']}",
                'severity': 'critical' if port in (6379, 27017, 9200, 11211) else 'high',
                'risk_score': 8.5 if port in (6379, 27017) else 7.5,
                'risk_inputs': [f'port={port}', f'product={product}', 'exposure=public'],
                'summary_md': f"Port **{port}** ({product}) is reachable from the public internet on **{host_e['label']}**"
                              + (f" (subdomain: {', '.join(sub_labels)})" if sub_labels else '')
                              + f". {svc_product or product} should never be directly exposed — it allows unauthenticated "
                              + "data access or remote code execution depending on configuration.",
                'evidence_chain': chain,
                'evidence': [
                    {'ref': e['ref'], 'fact': 'port_open_public', 'detail': {'port': port, 'product': product}},
                ],
                'affected_assets': [hr],
                'vuln_refs': [],
                'remediation_md': f"1. Restrict port {port} to internal networks (VPC security group / firewall rule).\n"
                                  f"2. If remote access is needed, use SSH tunnelling or a VPN.\n"
                                  f"3. Enable authentication if not already configured.",
            })
    return issues


def rule_dev_staging_exposed(entities, relations):
    """Dev/staging/test subdomains exposed to the internet."""
    issues = []
    for e in entities:
        if e['type'] != 'sub':
            continue
        fqdn = e['attrs'].get('fqdn', e['label']).lower()
        label_part = fqdn.split('.')[0]
        matched_pattern = None
        for pat in DEV_PATTERNS:
            if pat in label_part:
                matched_pattern = pat
                break
        if not matched_pattern:
            continue
        if not e['attrs'].get('resolved', False):
            continue

        # Find host
        host_refs = [r['target'] for r in relations if r['source'] == e['ref'] and r['type'] == 'RESOLVES_TO']
        chain = [e['ref']] + host_refs[:1]

        issues.append({
            'ref': _issue_ref('dev-staging-exposed', e['ref'], matched_pattern),
            'rule_id': 'dev-staging-exposed',
            'title': f"Dev/staging subdomain exposed: {fqdn}",
            'severity': 'medium',
            'risk_score': 5.0,
            'risk_inputs': [f'pattern={matched_pattern}', 'exposure=public'],
            'summary_md': f"The subdomain **{fqdn}** matches the pattern `{matched_pattern}`, indicating a "
                          f"development or staging environment. It resolves to a public IP, potentially exposing "
                          f"unfinished code, debug endpoints, or test data.",
            'evidence_chain': chain,
            'evidence': [
                {'ref': e['ref'], 'fact': 'dev_hostname', 'detail': {'pattern': matched_pattern, 'fqdn': fqdn}},
            ],
            'affected_assets': [e['ref']],
            'vuln_refs': [],
            'remediation_md': f"1. If {fqdn} is not needed publicly, restrict DNS or remove the record.\n"
                              f"2. If it must be public, ensure it has the same security controls as production.\n"
                              f"3. Never run debug mode or expose admin panels on dev/staging hosts.",
        })
    return issues


def rule_missing_security_headers(entities, relations):
    """Web applications missing critical security headers."""
    issues = []
    for e in entities:
        if e['type'] != 'sub':
            continue
        if not e['attrs'].get('has_webapp'):
            continue
        missing = e['attrs'].get('missing_headers', [])
        score = e['attrs'].get('security_header_score', 6)
        if score is None:
            score = 6
        if score >= 4:  # 4+ out of 6 = acceptable
            continue
        critical_missing = [h for h in missing if h in ('strict-transport-security', 'content-security-policy', 'x-content-type-options')]
        if not critical_missing:
            continue

        fqdn = e['attrs'].get('fqdn', e['label'])
        severity = 'high' if score == 0 else 'medium'

        issues.append({
            'ref': _issue_ref('missing-headers', e['ref'], ''),
            'rule_id': 'missing-headers',
            'title': f"Missing security headers on {fqdn} ({score}/6)",
            'severity': severity,
            'risk_score': 6.0 if score == 0 else 4.5,
            'risk_inputs': [f'header_score={score}/6', f'missing={len(missing)}'],
            'summary_md': f"**{fqdn}** is missing {len(missing)} security headers (score {score}/6). "
                          f"Critical missing: {', '.join(critical_missing)}. "
                          f"This exposes the application to clickjacking, MIME-sniffing, and XSS attacks.",
            'evidence_chain': [e['ref']],
            'evidence': [
                {'ref': e['ref'], 'fact': 'missing_headers', 'detail': {'score': score, 'missing': missing}},
            ],
            'affected_assets': [e['ref']],
            'vuln_refs': [],
            'remediation_md': "Add the following headers to all HTTP responses:\n"
                              "- `Strict-Transport-Security: max-age=31536000; includeSubDomains`\n"
                              "- `Content-Security-Policy: default-src 'self'`\n"
                              "- `X-Content-Type-Options: nosniff`\n"
                              "- `X-Frame-Options: DENY`\n"
                              "- `Referrer-Policy: strict-origin-when-cross-origin`\n"
                              "- `Permissions-Policy: camera=(), microphone=()`",
        })
    return issues


def rule_leaked_secrets(entities, relations):
    """Leaked API keys or credentials found in source/JS."""
    issues = []
    for e in entities:
        if e['type'] != 'vuln':
            continue
        if e['attrs'].get('source') != 'Secret Scan':
            continue
        template = e['attrs'].get('template', '')
        host = e['attrs'].get('host', 'Unknown')
        url = e['attrs'].get('url', '')

        # Find sub for this host
        sub_r = ke._sub_ref(host) if host != 'Unknown' else None
        chain = [sub_r, e['ref']] if sub_r else [e['ref']]

        issues.append({
            'ref': _issue_ref('leaked-secret', e['ref'], ''),
            'rule_id': 'leaked-secret',
            'title': f"Leaked credential: {template}",
            'severity': 'critical',
            'risk_score': 9.0,
            'risk_inputs': ['source=trufflehog', 'type=credential', 'exposure=public_js'],
            'summary_md': f"A **{template}** was found exposed in a publicly accessible file"
                          + (f" on **{host}**" if host != 'Unknown' else '')
                          + f". URL: `{url[:120]}`. This credential should be rotated immediately.",
            'evidence_chain': chain,
            'evidence': [
                {'ref': e['ref'], 'fact': 'leaked_credential', 'detail': {'template': template, 'host': host}},
            ],
            'affected_assets': [sub_r] if sub_r else [],
            'vuln_refs': [e['ref']],
            'remediation_md': f"1. **Rotate the {template} immediately** — assume it has been compromised.\n"
                              f"2. Review access logs for unauthorized use.\n"
                              f"3. Remove the credential from the source file.\n"
                              f"4. Use environment variables or a secret manager instead of hardcoding.",
        })
    return issues


def rule_new_asset(entities, relations, previous_entities=None):
    """Assets appearing for the first time (not seen in previous scan)."""
    if not previous_entities:
        return []
    prev_refs = {e['ref'] for e in previous_entities}
    issues = []
    for e in entities:
        if e['type'] != 'sub':
            continue
        if e['ref'] in prev_refs:
            continue
        if not e['attrs'].get('resolved', False):
            continue
        fqdn = e['attrs'].get('fqdn', e['label'])
        issues.append({
            'ref': _issue_ref('new-asset', e['ref'], ''),
            'rule_id': 'new-asset',
            'title': f"New subdomain discovered: {fqdn}",
            'severity': 'info',
            'risk_score': 2.0,
            'risk_inputs': ['type=new_subdomain', 'first_seen=current_rev'],
            'summary_md': f"**{fqdn}** was not seen in the previous scan. New assets may indicate "
                          f"shadow IT, unsanctioned deployments, or legitimate infrastructure changes. "
                          f"Review to confirm it is expected.",
            'evidence_chain': [e['ref']],
            'evidence': [
                {'ref': e['ref'], 'fact': 'new_asset', 'detail': {'fqdn': fqdn}},
            ],
            'affected_assets': [e['ref']],
            'vuln_refs': [],
            'remediation_md': "1. Verify the subdomain is authorized and expected.\n"
                              "2. Ensure it follows the same security policies as production.\n"
                              "3. If unsanctioned, investigate who created it and why.",
        })
    return issues


def rule_webapp_no_waf(entities, relations):
    """Web application without WAF protection."""
    issues = []
    for e in entities:
        if e['type'] != 'sub':
            continue
        if not e['attrs'].get('has_webapp'):
            continue
        waf = (e['attrs'].get('waf_vendor') or '').strip().lower()
        if waf and waf != 'none':
            continue
        fqdn = e['attrs'].get('fqdn', e['label'])

        issues.append({
            'ref': _issue_ref('no-waf', e['ref'], ''),
            'rule_id': 'no-waf',
            'title': f"Web application without WAF: {fqdn}",
            'severity': 'medium',
            'risk_score': 4.0,
            'risk_inputs': ['waf=none', 'has_webapp=true'],
            'summary_md': f"**{fqdn}** serves a web application but has no detectable WAF "
                          f"(Web Application Firewall). This exposes the application directly to "
                          f"automated attacks, scanners, and exploitation attempts.",
            'evidence_chain': [e['ref']],
            'evidence': [
                {'ref': e['ref'], 'fact': 'no_waf', 'detail': {'fqdn': fqdn}},
            ],
            'affected_assets': [e['ref']],
            'vuln_refs': [],
            'remediation_md': "1. Deploy a WAF (e.g. Cloudflare, AWS WAF, Akamai) in front of the application.\n"
                              "2. Configure WAF rules for OWASP Top 10 protections.\n"
                              "3. Enable rate limiting and bot protection.",
        })
    return issues


# ---------------------------------------------------------------------------
# Rule registry
# ---------------------------------------------------------------------------

ALL_RULES = {
    'exposed-service': rule_exposed_service,
    'dev-staging-exposed': rule_dev_staging_exposed,
    'missing-headers': rule_missing_security_headers,
    'leaked-secret': rule_leaked_secrets,
    'new-asset': rule_new_asset,
    'no-waf': rule_webapp_no_waf,
}


def run_rules(entities, relations, previous_entities=None, disabled_rules=None):
    """Execute all enabled correlation rules.  Returns a list of computed issues."""
    disabled = set(disabled_rules or [])
    computed = []
    for rule_id, fn in ALL_RULES.items():
        if rule_id in disabled:
            continue
        try:
            if rule_id == 'new-asset':
                results = fn(entities, relations, previous_entities=previous_entities)
            else:
                results = fn(entities, relations)
            computed.extend(results)
        except Exception:
            logger.exception(f"Rule {rule_id} failed")
    return computed


# ---------------------------------------------------------------------------
# State management — issues-state.json (INV-2)
# ---------------------------------------------------------------------------

def state_dir(target):
    """Return the sacred state/ directory for a target."""
    base = os.path.dirname(os.path.abspath(__file__))
    d = os.path.join(base, 'state', target)
    os.makedirs(d, exist_ok=True)
    return d


def _state_path(target):
    return os.path.join(state_dir(target), 'issues-state.json')


def _events_path(target):
    return os.path.join(state_dir(target), 'events.jsonl')


def load_state(target):
    """Load the stored half of all issues for a target."""
    path = _state_path(target)
    if not os.path.exists(path):
        return {}
    try:
        with open(path) as f:
            return json.load(f)
    except Exception:
        logger.exception(f"Failed to load issues-state for {target}")
        return {}


def _atomic_write_json(path, data):
    """Write JSON atomically: temp → rename, keep .bak of prior version."""
    dir_path = os.path.dirname(path)
    if os.path.exists(path):
        bak = path + '.bak'
        try:
            shutil.copy2(path, bak)
        except Exception:
            pass  # best-effort backup
    try:
        fd, tmp = tempfile.mkstemp(dir=dir_path, suffix='.tmp')
        with os.fdopen(fd, 'w') as f:
            json.dump(data, f, indent=2, sort_keys=True)
        os.rename(tmp, path)
    except Exception:
        logger.exception(f"Atomic write failed for {path}")
        # Try to clean up temp
        try:
            os.unlink(tmp)
        except Exception:
            pass
        raise


def save_state(target, state_dict):
    """Atomically save the issues-state.json."""
    _atomic_write_json(_state_path(target), state_dict)


# ---------------------------------------------------------------------------
# Correlate step — the main pipeline hook
# ---------------------------------------------------------------------------

def correlate(target, scan_id, computed_issues, state=None):
    """Run the INV-2 merge: computed issues + stored state → merged issues + updated state.

    Returns:
        merged: list of full Issue dicts (computed + state overlay)
        new_state: the updated state dict (caller should save)
        events: list of timeline events emitted
    """
    now = datetime.utcnow().isoformat(timespec='seconds') + 'Z'
    if state is None:
        state = load_state(target)

    computed_refs = {i['ref'] for i in computed_issues}
    computed_map = {i['ref']: i for i in computed_issues}
    events = []

    # 1. Process each computed issue
    for ci in computed_issues:
        ref = ci['ref']
        if ref in state:
            # Existing — update detections, last_seen
            st = state[ref]
            st['detections'] = st.get('detections', 0) + 1
            st['last_seen_rev'] = scan_id
            st['last_seen_at'] = now
            # Clear orphan flag if reattaching
            if st.get('orphaned_at'):
                del st['orphaned_at']
            # Reopen if auto-resolved
            if st.get('status') == 'resolved':
                st['status'] = 'open'
                st['history'].append({'at': now, 'event': 'reopened', 'by': 'system'})
                events.append({'kind': 'issue_reopened', 'ref': ref, 'rev': scan_id, 'at': now})
        else:
            # New issue
            state[ref] = {
                'status': 'open',
                'first_seen_rev': scan_id,
                'first_seen_at': now,
                'last_seen_rev': scan_id,
                'last_seen_at': now,
                'detections': 1,
                'assignee': None,
                'history': [{'at': now, 'event': 'created', 'by': 'system'}],
            }
            events.append({'kind': 'issue_created', 'ref': ref, 'rev': scan_id, 'at': now,
                           'detail': {'title': ci.get('title', ''), 'severity': ci.get('severity', '')}})

    # 2. Auto-resolve: open issues NOT in computed set (but not false_positive/accepted_risk — INV-2)
    human_statuses = {'false_positive', 'accepted_risk'}
    for ref, st in state.items():
        if ref not in computed_refs:
            if st.get('status') in ('open', 'acknowledged', 'in_progress'):
                st['status'] = 'resolved'
                st.setdefault('history', []).append({'at': now, 'event': 'auto_resolved', 'by': 'system'})
                events.append({'kind': 'issue_auto_resolved', 'ref': ref, 'rev': scan_id, 'at': now})
            elif st.get('status') not in human_statuses and not st.get('orphaned_at'):
                # Tombstone orphans (rule removed/edited) — never delete
                st['orphaned_at'] = now

    # 3. Merge computed + state → full issues
    merged = []
    for ci in computed_issues:
        ref = ci['ref']
        st = state.get(ref, {})
        full = dict(ci)
        full['status'] = st.get('status', 'open')
        full['first_seen_rev'] = st.get('first_seen_rev', scan_id)
        full['first_seen_at'] = st.get('first_seen_at', now)
        full['last_seen_rev'] = st.get('last_seen_rev', scan_id)
        full['last_seen_at'] = st.get('last_seen_at', now)
        full['detections'] = st.get('detections', 1)
        full['assignee'] = st.get('assignee')
        full['history'] = st.get('history', [])
        merged.append(full)

    # Also include non-orphaned resolved/state-only issues so they show in history
    for ref, st in state.items():
        if ref not in computed_refs and st.get('status') in ('resolved', 'false_positive', 'accepted_risk') and not st.get('orphaned_at'):
            # Create a minimal Issue for display
            merged.append({
                'ref': ref, 'rule_id': 'unknown', 'title': f'Resolved issue {ref}',
                'severity': 'info', 'risk_score': 0, 'risk_inputs': [],
                'summary_md': 'This issue was auto-resolved (evidence no longer detected).',
                'evidence_chain': [], 'evidence': [], 'affected_assets': [], 'vuln_refs': [],
                'remediation_md': '',
                'status': st['status'],
                'first_seen_rev': st.get('first_seen_rev', ''),
                'first_seen_at': st.get('first_seen_at', ''),
                'last_seen_rev': st.get('last_seen_rev', ''),
                'last_seen_at': st.get('last_seen_at', ''),
                'detections': st.get('detections', 0),
                'assignee': st.get('assignee'),
                'history': st.get('history', []),
            })

    return merged, state, events


# ---------------------------------------------------------------------------
# Timeline — events.jsonl (append-only, idempotent)
# ---------------------------------------------------------------------------

def _load_existing_event_keys(target):
    """Load existing event identity keys for idempotent append."""
    path = _events_path(target)
    keys = set()
    if not os.path.exists(path):
        return keys
    try:
        with open(path) as f:
            for line in f:
                try:
                    ev = json.loads(line)
                    keys.add((ev.get('rev', ''), ev.get('kind', ''), ev.get('ref', '')))
                except Exception:
                    continue
    except Exception:
        pass
    return keys


def append_events(target, events, rev=None):
    """Append events to events.jsonl, deduping on (rev, kind, ref)."""
    if not events:
        return
    existing = _load_existing_event_keys(target)
    path = _events_path(target)
    new_lines = []
    for ev in events:
        r = ev.get('rev', rev or '')
        key = (r, ev.get('kind', ''), ev.get('ref', ''))
        if key in existing:
            continue
        existing.add(key)
        ev['rev'] = r
        new_lines.append(json.dumps(ev, separators=(',', ':'), sort_keys=True))
    if new_lines:
        with open(path, 'a') as f:
            for line in new_lines:
                f.write(line + '\n')


def load_events(target, kind=None, limit=200):
    """Load timeline events, newest first."""
    path = _events_path(target)
    if not os.path.exists(path):
        return []
    events = []
    try:
        with open(path) as f:
            for line in f:
                try:
                    ev = json.loads(line)
                    if kind and ev.get('kind') != kind:
                        continue
                    events.append(ev)
                except Exception:
                    continue
    except Exception:
        pass
    events.reverse()  # newest first
    return events[:limit]


# ---------------------------------------------------------------------------
# Revision differ — emits timeline events from two scans
# ---------------------------------------------------------------------------

def diff_revisions(current_entities, previous_entities, scan_id, prev_scan_id):
    """Diff two entity indexes and emit timeline events."""
    now = datetime.utcnow().isoformat(timespec='seconds') + 'Z'
    curr_refs = {e['ref']: e for e in current_entities}
    prev_refs = {e['ref']: e for e in previous_entities}
    events = []

    # New entities
    for ref in sorted(set(curr_refs) - set(prev_refs)):
        e = curr_refs[ref]
        kind_map = {'sub': 'new_subdomain', 'host': 'new_ip', 'svc': 'port_opened', 'vuln': 'new_vuln_match'}
        kind = kind_map.get(e['type'])
        if kind:
            events.append({
                'kind': kind, 'ref': ref, 'rev': scan_id, 'from_rev': prev_scan_id, 'at': now,
                'detail': {'label': e.get('label', ''), 'type': e['type']},
            })

    # Removed entities
    for ref in sorted(set(prev_refs) - set(curr_refs)):
        e = prev_refs[ref]
        kind_map = {'sub': 'subdomain_gone', 'host': 'ip_gone', 'svc': 'port_closed'}
        kind = kind_map.get(e['type'])
        if kind:
            events.append({
                'kind': kind, 'ref': ref, 'rev': scan_id, 'from_rev': prev_scan_id, 'at': now,
                'detail': {'label': e.get('label', ''), 'type': e['type']},
            })

    # Service changes (same ref, different attrs)
    for ref in sorted(set(curr_refs) & set(prev_refs)):
        if curr_refs[ref]['type'] != 'svc':
            continue
        ca = curr_refs[ref]['attrs']
        pa = prev_refs[ref]['attrs']
        if ca.get('product') != pa.get('product') or ca.get('version') != pa.get('version'):
            events.append({
                'kind': 'service_changed', 'ref': ref, 'rev': scan_id, 'from_rev': prev_scan_id, 'at': now,
                'detail': {
                    'label': curr_refs[ref].get('label', ''),
                    'was': f"{pa.get('product','')} {pa.get('version','')}".strip(),
                    'now': f"{ca.get('product','')} {ca.get('version','')}".strip(),
                },
            })

    return events


# ---------------------------------------------------------------------------
# Field coverage audit (Phase 0 deliverable)
# ---------------------------------------------------------------------------

RULE_FIELD_REQUIREMENTS = {
    'exposed-service': ['svc.port', 'host.ip'],
    'dev-staging-exposed': ['sub.fqdn', 'sub.resolved'],
    'missing-headers': ['sub.has_webapp', 'sub.security_header_score', 'sub.missing_headers'],
    'leaked-secret': ['vuln.source=Secret Scan'],
    'new-asset': ['sub.fqdn', 'sub.resolved'],
    'no-waf': ['sub.has_webapp', 'sub.waf_vendor'],
    # Future rules (❓ pending audit)
    'subdomain-takeover': ['sub.cname_chain', 'sub.dangling'],
    'expired-cert': ['cert.not_after', 'cert.self_signed'],
    'known-exploited-vuln': ['vuln.cve_id', 'vuln.kev'],
    'eol-software': ['tech.product', 'tech.version', 'tech.eol_date'],
}


def audit_field_coverage(entities):
    """Produce field-coverage.json: which fields exist in the data."""
    coverage = {}
    for field_spec in set(f for reqs in RULE_FIELD_REQUIREMENTS.values() for f in reqs):
        parts = field_spec.split('.')
        etype = parts[0]
        if '=' in parts[-1]:
            fname, expected = parts[-1].split('=', 1)
        else:
            fname = parts[-1] if len(parts) > 1 else ''
            expected = None

        matching = [e for e in entities if e['type'] == etype]
        if not matching:
            coverage[field_spec] = {'present_pct': 0, 'sample_values': [], 'count': 0}
            continue

        if expected:
            hits = [e for e in matching if str(e.get('attrs', {}).get(fname, '')) == expected]
        elif fname:
            hits = [e for e in matching if e.get('attrs', {}).get(fname) is not None]
        else:
            hits = matching

        pct = round(len(hits) / len(matching) * 100, 1) if matching else 0
        samples = []
        for e in hits[:3]:
            v = e.get('attrs', {}).get(fname) if fname else e.get('label', '')
            samples.append(str(v)[:80] if v is not None else '')
        coverage[field_spec] = {'present_pct': pct, 'sample_values': samples, 'count': len(hits)}

    # Rule readiness
    rule_status = {}
    for rule_id, fields in RULE_FIELD_REQUIREMENTS.items():
        missing = [f for f in fields if coverage.get(f, {}).get('present_pct', 0) == 0]
        rule_status[rule_id] = {
            'ready': len(missing) == 0,
            'missing_fields': missing,
            'enabled': rule_id in ALL_RULES and len(missing) == 0,
        }

    return {'fields': coverage, 'rules': rule_status}
