#!/usr/bin/env python3
"""
ARISE job runner + scheduler.

- launch_scan(target): spawns `easm-pipeline.sh <target>` as a DETACHED process
  (new session) so long scans survive a dashboard restart. Tracked under
  jobs/<job_id>/{meta.json,status.json,output.log,pid,exit_code}.
- Status is reconciled by checking pid liveness + the exit_code file.
- APScheduler drives recurring scans from schedules.json (per-target cadence).

Shell-injection safe: the target is passed as a positional parameter to bash,
never concatenated into a command string.
"""

import os
import re
import json
import signal
import subprocess
import threading
from datetime import datetime

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
JOBS_DIR = os.path.join(BASE_DIR, 'jobs')
SCHEDULES_FILE = os.path.join(BASE_DIR, 'schedules.json')
PIPELINE = os.path.join(BASE_DIR, 'easm-pipeline.sh')

VALID_TARGET = re.compile(r'^[A-Za-z0-9]([A-Za-z0-9.\-_:]{0,252}[A-Za-z0-9])?$')
FREQUENCIES = ('off', 'daily', 'weekly', 'monthly', 'once', 'custom')

_LOCK = threading.RLock()
_SCHEDULER = None


# ---------------------------------------------------------------------------
# helpers
# ---------------------------------------------------------------------------
def _read_json(path, default):
    try:
        with open(path) as fh:
            return json.load(fh)
    except Exception:
        return default


def _write_json(path, obj):
    tmp = path + '.tmp'
    with open(tmp, 'w') as fh:
        json.dump(obj, fh, indent=2)
    os.replace(tmp, path)


def sanitize_target(target):
    t = (target or '').strip().lower()
    # strip scheme / trailing path if a URL was pasted
    t = re.sub(r'^https?://', '', t)
    t = t.split('/')[0].strip()
    if not t or not VALID_TARGET.match(t):
        return None
    return t


def _pid_alive(pid):
    if not pid:
        return False
    try:
        os.kill(int(pid), 0)
        return True
    except (OSError, ValueError):
        return False


def _reap(pid):
    """Non-blocking reap of a child process (prevents zombies).

    Returns the exit code if the process was our child and has finished
    (negative-ish signals mapped to 128+signal), or None if it's still
    running or is not our child (e.g. reparented to init after a dashboard
    restart, which raises ECHILD).
    """
    if not pid:
        return None
    try:
        wpid, wstatus = os.waitpid(int(pid), os.WNOHANG)
    except (OSError, ValueError):
        return None                      # ECHILD / not our child / bad pid
    if wpid == 0:
        return None                      # still running
    if os.WIFEXITED(wstatus):
        return os.WEXITSTATUS(wstatus)
    if os.WIFSIGNALED(wstatus):
        return 128 + os.WTERMSIG(wstatus)
    return 1


# ---------------------------------------------------------------------------
# jobs
# ---------------------------------------------------------------------------
def _job_dir(job_id):
    return os.path.join(JOBS_DIR, job_id)


def _reconcile(job_id):
    """Return the current status dict for a job, updating running->done/failed."""
    d = _job_dir(job_id)
    status = _read_json(os.path.join(d, 'status.json'), None)
    if not status:
        return None
    if status.get('status') == 'running':
        pid = status.get('pid')
        # Reap first: clears the zombie and tells us if a still-parented child
        # has exited (e.g. after an Emergency Stop / SIGTERM).
        reaped = _reap(pid)
        exit_file = os.path.join(d, 'exit_code')
        if os.path.exists(exit_file):
            # Pipeline finished normally and recorded its own exit code.
            try:
                code = int(open(exit_file).read().strip() or '1')
            except ValueError:
                code = 1
            status['status'] = 'done' if code == 0 else 'failed'
            status['exit_code'] = code
            status['ended_at'] = datetime.now().isoformat(timespec='seconds')
            _write_json(os.path.join(d, 'status.json'), status)
        elif reaped is not None:
            # Child exited without writing an exit code — killed/stopped.
            status['status'] = 'done' if reaped == 0 else 'failed'
            status['exit_code'] = reaped
            status['ended_at'] = datetime.now().isoformat(timespec='seconds')
            if reaped != 0:
                status['note'] = 'scan stopped before completion'
            _write_json(os.path.join(d, 'status.json'), status)
        elif not _pid_alive(pid):
            # Not our child and no longer alive (e.g. killed after a restart).
            status['status'] = 'failed'
            status['exit_code'] = None
            status['ended_at'] = datetime.now().isoformat(timespec='seconds')
            status['note'] = 'process ended without exit code (killed?)'
            _write_json(os.path.join(d, 'status.json'), status)
    return status


def list_jobs():
    if not os.path.isdir(JOBS_DIR):
        return []
    out = []
    for jid in os.listdir(JOBS_DIR):
        if not os.path.isdir(_job_dir(jid)):
            continue
        st = _reconcile(jid)
        if st:
            out.append(st)
    out.sort(key=lambda s: s.get('started_at', ''), reverse=True)
    return out


def job_status(job_id):
    return _reconcile(job_id)


def is_target_running(target):
    for st in list_jobs():
        if st.get('target') == target and st.get('status') == 'running':
            return st
    return None


def launch_scan(target, source='manual'):
    """Launch a detached pipeline run. Returns (job_dict, error_or_None)."""
    t = sanitize_target(target)
    if not t:
        return None, "Invalid target. Use a hostname/domain like example.com."
    if not os.path.exists(PIPELINE):
        return None, f"Pipeline script not found at {PIPELINE}."

    with _LOCK:
        running = is_target_running(t)
        if running:
            return None, f"A scan for {t} is already running (job {running['job_id']})."

        os.makedirs(JOBS_DIR, exist_ok=True)
        ts = datetime.now().strftime('%Y%m%d-%H%M%S')
        job_id = f"{t}-{ts}"
        d = _job_dir(job_id)
        os.makedirs(d, exist_ok=True)

        log_path = os.path.join(d, 'output.log')
        exit_path = os.path.join(d, 'exit_code')
        meta = {
            'job_id': job_id, 'target': t, 'source': source,
            'started_at': datetime.now().isoformat(timespec='seconds'),
            'pipeline': PIPELINE,
        }
        _write_json(os.path.join(d, 'meta.json'), meta)

        # positional params ($1=pipeline, $2=target, $3=exit_file) => injection-safe
        wrapper = 'bash "$1" "$2"; echo $? > "$3"'
        logf = open(log_path, 'ab', buffering=0)
        try:
            proc = subprocess.Popen(
                ['bash', '-c', wrapper, 'arise-job', PIPELINE, t, exit_path],
                cwd=BASE_DIR,
                stdout=logf,
                stderr=subprocess.STDOUT,
                stdin=subprocess.DEVNULL,
                start_new_session=True,   # detach: survives dashboard restart
            )
        except Exception as exc:  # noqa: BLE001
            logf.close()
            return None, f"Failed to launch scan: {exc}"

        with open(os.path.join(d, 'pid'), 'w') as fh:
            fh.write(str(proc.pid))
        status = {
            'job_id': job_id, 'target': t, 'source': source, 'pid': proc.pid,
            'status': 'running',
            'started_at': meta['started_at'],
            'log': os.path.relpath(log_path, BASE_DIR),
        }
        _write_json(os.path.join(d, 'status.json'), status)
        return status, None


def tail_log(job_id, lines=200):
    d = _job_dir(job_id)
    log_path = os.path.join(d, 'output.log')
    if not os.path.exists(log_path):
        return ''
    try:
        with open(log_path, 'rb') as fh:
            data = fh.read()
        text = data.decode('utf-8', errors='replace')
        return '\n'.join(text.splitlines()[-lines:])
    except Exception:
        return ''


def stop_job(job_id):
    """Best-effort terminate a running job's process group."""
    st = _reconcile(job_id)
    if not st or st.get('status') != 'running':
        return False, "Job is not running."
    pid = st.get('pid')
    try:
        os.killpg(os.getpgid(int(pid)), signal.SIGTERM)
    except Exception:
        try:
            os.kill(int(pid), signal.SIGTERM)
        except Exception as exc:  # noqa: BLE001
            return False, f"Could not stop job: {exc}"
    return True, "Stop signal sent."


def stop_all_jobs():
    """Emergency stop: terminate every currently-running job.

    Returns (stopped_count, [errors]). Safe to call when nothing is running.
    """
    stopped = 0
    errors = []
    for st in list_jobs():
        if st.get('status') != 'running':
            continue
        jid = st.get('job_id')
        ok, msg = stop_job(jid)
        if ok:
            stopped += 1
        else:
            errors.append(f"{jid}: {msg}")
    return stopped, errors


# ---------------------------------------------------------------------------
# scheduler (APScheduler)
# ---------------------------------------------------------------------------
def load_schedules():
    return _read_json(SCHEDULES_FILE, {})


def _save_schedules(sch):
    _write_json(SCHEDULES_FILE, sch)


def _make_trigger(frequency, cron, hour=2, minute=0, day_of_week=None, day_of_month=None, run_date=None):
    from apscheduler.triggers.cron import CronTrigger
    from apscheduler.triggers.date import DateTrigger
    if frequency == 'daily':
        return CronTrigger(hour=hour, minute=minute)
    if frequency == 'weekly':
        dow = day_of_week if day_of_week is not None else 'sun'
        return CronTrigger(day_of_week=dow, hour=hour, minute=minute)
    if frequency == 'monthly':
        dom = int(day_of_month) if day_of_month else 1
        return CronTrigger(day=dom, hour=hour, minute=minute)
    if frequency == 'once':
        if not run_date:
            raise ValueError("once frequency requires a run_date")
        return DateTrigger(run_date=run_date)
    if frequency == 'custom':
        if not cron:
            raise ValueError("custom frequency requires a cron string")
        return CronTrigger.from_crontab(cron)
    raise ValueError(f"unschedulable frequency: {frequency}")


def _scheduled_run(target):
    launch_scan(target, source='schedule')


def init_scheduler():
    """Start APScheduler and register jobs from schedules.json. Degrades if missing."""
    global _SCHEDULER
    if _SCHEDULER is not None:
        return _SCHEDULER
    try:
        from apscheduler.schedulers.background import BackgroundScheduler
    except ImportError:
        print("[jobs] APScheduler not installed — scheduled scans disabled. "
              "Run: pip install APScheduler")
        return None
    _SCHEDULER = BackgroundScheduler(daemon=True)
    _SCHEDULER.start()
    for target, cfg in load_schedules().items():
        freq = cfg.get('frequency', 'off')
        if freq in ('off', None):
            continue
        try:
            trigger = _make_trigger(freq, cfg.get('cron'),
                                    hour=cfg.get('hour', 2), minute=cfg.get('minute', 0),
                                    day_of_week=cfg.get('day_of_week'),
                                    day_of_month=cfg.get('day_of_month'),
                                    run_date=cfg.get('run_date'))
            _SCHEDULER.add_job(_scheduled_run, trigger,
                               args=[target], id=f"scan:{target}", replace_existing=True)
        except Exception as exc:  # noqa: BLE001
            print(f"[jobs] Could not schedule {target}: {exc}")
    return _SCHEDULER


def set_schedule(target, frequency, cron=None, hour=2, minute=0,
                  day_of_week=None, day_of_month=None, run_date=None):
    t = sanitize_target(target)
    if not t:
        return None, "Invalid target."
    if frequency not in FREQUENCIES:
        return None, f"frequency must be one of {FREQUENCIES}"
    with _LOCK:
        sch = load_schedules()
        if frequency == 'off':
            sch.pop(t, None)
            _save_schedules(sch)
            if _SCHEDULER:
                try:
                    _SCHEDULER.remove_job(f"scan:{t}")
                except Exception:
                    pass
            return {'target': t, 'frequency': 'off'}, None

        cfg = {'frequency': frequency, 'cron': cron, 'enabled': True,
               'hour': hour, 'minute': minute,
               'day_of_week': day_of_week, 'day_of_month': day_of_month,
               'run_date': run_date}
        if _SCHEDULER:
            try:
                trigger = _make_trigger(frequency, cron, hour=hour, minute=minute,
                                        day_of_week=day_of_week, day_of_month=day_of_month,
                                        run_date=run_date)
                job = _SCHEDULER.add_job(_scheduled_run, trigger,
                                         args=[t], id=f"scan:{t}", replace_existing=True)
                cfg['next_run'] = job.next_run_time.isoformat() if job.next_run_time else None
            except Exception as exc:  # noqa: BLE001
                return None, f"Invalid schedule: {exc}"
        sch[t] = cfg
        _save_schedules(sch)
        return {'target': t, **cfg}, None


def list_schedules():
    sch = load_schedules()
    out = []
    for target, cfg in sch.items():
        next_run = cfg.get('next_run')
        if _SCHEDULER:
            job = _SCHEDULER.get_job(f"scan:{target}")
            if job and job.next_run_time:
                next_run = job.next_run_time.isoformat()
        out.append({'target': target, 'frequency': cfg.get('frequency', 'off'),
                    'cron': cfg.get('cron'), 'next_run': next_run,
                    'hour': cfg.get('hour', 2), 'minute': cfg.get('minute', 0),
                    'day_of_week': cfg.get('day_of_week'),
                    'day_of_month': cfg.get('day_of_month'),
                    'run_date': cfg.get('run_date')})
    return out
