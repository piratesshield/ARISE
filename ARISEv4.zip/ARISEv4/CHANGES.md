# KAIJU EASM — Correlation & Conclusion Layer: Build Report

**Built against:** `KAIJU-EASM-Correlation-UX-Spec-v1.1.md`
**Date:** 2026-07-11

---

## Phase 0 — Foundations (Data audit + Entity index + State infrastructure)

### What was built

**`kaiju_entities.py`** — Entity index engine (INV-1 compliant)
- `_ref(etype, natural_key)` — derives stable entity refs via `sha1(natural_key)[:10]`. Every ref is deterministic: recomputing the same scan twice produces **byte-identical refs** (verified by test).
- `build_entity_index(scan_data)` — single pass over `get_scan_data()` output, produces typed entities + relations:
  - **7 entity types:** `domain`, `sub` (subdomain), `host` (keyed on IP — see DECISIONS.md), `svc` (service), `tech` (technology), `vuln`, `cert`
  - **6 relation types:** `HAS_SUB`, `RESOLVES_TO`, `RUNS`, `USES`, `AFFECTS`, and implicit entity-to-entity links
  - Each entity carries `ref`, `type`, `label`, `attrs` (all scan fields), `provenance[]` (which scanner produced it)
- `save_entity_index()` / `load_entity_index()` — caches to `scans/<id>/.derived/entities.json` (regenerable; safe to delete)
- `related(relations, ref, hops)` — N-hop graph traversal for the entity drawer's Related tab
- `entities_by_type()`, `entity_by_ref()` — lookup helpers

**`kaiju_issues.py`** — Correlation engine + state management (INV-1 + INV-2 compliant)

*Correlation rules (6 rules, all verified against real data):*
- `exposed-service` — sensitive DB/cache ports (3306, 5432, 6379, 27017, etc.) exposed to the internet
- `dev-staging-exposed` — dev/staging/test subdomains resolving to public IPs
- `missing-headers` — web apps missing critical security headers (HSTS, CSP, X-Content-Type-Options)
- `leaked-secret` — API keys/credentials found by TruffleHog in JS files
- `new-asset` — subdomains appearing for the first time vs. previous scan
- `no-waf` — web applications without WAF protection

*Issue lifecycle (INV-2):*
- `correlate(target, scan_id, computed, state)` — the merge engine:
  1. Each computed issue is matched against `issues-state.json` by ref
  2. New issues get `status=open`, `detections=1`, history `created`
  3. Re-detected issues get `detections += 1`, `last_seen_rev` updated
  4. Open issues not in computed set get `status=resolved`, history `auto_resolved`
  5. **Human-set statuses (`false_positive`, `accepted_risk`) are NEVER auto-resolved** (INV-2)
  6. Orphaned state entries (rule removed/edited) are **tombstoned** (`orphaned_at` set), never deleted
  7. If a tombstoned issue recomputes later, state **reattaches** (reopen for free)

*Atomic writes:*
- `_atomic_write_json()` — writes to temp file, `os.rename()` onto target, keeps `.bak` of prior version
- `append_events()` — idempotent on `(rev, kind, ref)` — re-running a pipeline never duplicates events

*Timeline:*
- `diff_revisions(current_entities, previous_entities, scan_id, prev_scan_id)` — emits events: `new_subdomain`, `subdomain_gone`, `new_ip`, `port_opened`, `port_closed`, `service_changed`, `new_vuln_match`
- Events stored in `state/<target>/events.jsonl` (append-only, retention-exempt, Drive-synced)

*Field coverage audit:*
- `audit_field_coverage(entities)` — produces `field-coverage.json` mapping every rule input to presence % + sample values
- `RULE_FIELD_REQUIREMENTS` — declares which fields each rule needs
- Rule engine reads this at startup to auto-disable rules with missing fields

### On-disk layout created

```
state/<target>/                  ← SACRED. Retention-exempt. Drive-synced first.
  issues-state.json              ← Stored half (status, first_seen, detections, history)
  issues-state.json.bak          ← Atomic write backup
  events.jsonl                   ← Append-only timeline

scans/<id>/.derived/             ← Regenerable cache
  entities.json                  ← Entity index
  field-coverage.json            ← Audit output
```

### Test results (against jungleerummy.com scan)

| Test | Result |
|------|--------|
| Entity count | 138 (1 domain, 67 subs, 16 hosts, 16 svcs, 5 techs, 33 vulns) |
| Relations | 262 |
| INV-1 (stable refs — byte-identical on recompute) | **PASS** |
| INV-2 (false_positive survives recompute) | **PASS** |
| Idempotent append (re-run doesn't duplicate events) | **PASS** |
| Computed issues | 52 (1 critical, 4 high, 47 medium) |
| Rules fired | 4 of 6 (dev-staging, missing-headers, leaked-secret, no-waf) |

### Field coverage audit results

| Field | Coverage | Status |
|-------|----------|--------|
| `svc.port` | 100% | Ready |
| `host.ip` | 100% | Ready |
| `sub.fqdn` | 100% | Ready |
| `sub.resolved` | 100% | Ready |
| `sub.has_webapp` | 100% | Ready |
| `sub.missing_headers` | 100% | Ready |
| `sub.security_header_score` | 43% | Ready |
| `sub.waf_vendor` | 15% | Ready |
| `vuln.source=Secret Scan` | 3% | Ready |
| `cert.not_after` | 0% | Blocked (no TLS data) |
| `vuln.cve_id` | 0% | Blocked (no CVE enrichment) |
| `vuln.kev` | 0% | Blocked (no KEV data) |
| `sub.cname_chain` | 0% | Blocked (no CNAME chain data) |
| `tech.eol_date` | 0% | Blocked (no EOL table) |

---

## Phase 1 — Entity Drawer (global component)

### What was built

**Entity drawer** — right slide-over panel (480px, `min(480px, 92vw)`) that opens from any entity reference anywhere in the app.

- **Surface:** card bg + left shadow (`-20px 0 60px rgba(0,0,0,.6)`), backdrop blur overlay
- **Header:** type icon (teal container) + name + close button
- **4 tabs per entity:**
  - **Summary** — all entity attributes as key/value pairs
  - **Related** — 1-hop graph neighbors grouped by type, each clickable to open *its* drawer (stack navigation)
  - **Issues** — all issues affecting this entity (from `/api/t/<target>/entities/<ref>/issues`)
  - **Raw** — provenance (which scanner), ref string (monospace), full JSON dump
- **Keyboard:** Esc closes, focus trapped while open
- **Wired to:** entity refs in issue rows, evidence chains, timeline events, and related-entity rows

**Issue detail drawer** — same component, specialized for Issue objects:
- **Header:** severity-colored icon + issue title
- **3 tabs:**
  - **Evidence** — severity badge, status pill, risk score, evidence chain (clickable chips with `→` separators), "Why this was flagged" (summary_md rendered with markdown-lite), evidence list (each ref clickable), risk inputs, **status change form** (dropdown + note textarea + update button, note required for false_positive/accepted_risk)
  - **Remediation** — rendered remediation_md
  - **History** — chronological event log (created, status_changed, auto_resolved, etc.)

### API routes added to `dashboard.py`

| Route | Method | Purpose |
|-------|--------|---------|
| `/api/t/<target>/entities/<ref>` | GET | Single entity by ref |
| `/api/t/<target>/entities/<ref>/related` | GET | N-hop related entities |
| `/api/t/<target>/entities/<ref>/issues` | GET | Issues affecting entity |

---

## Phase 2 — Deep-linked Numbers + Filter Chips

### What was built

**Issues lens** (`view-issues`) — the new default landing page:
- **Severity chips** in the header row — clickable toggles that filter by severity (e.g., `3 Critical` rose, `7 High` orange). Multiple can be active simultaneously.
- **Filter chip bar** — active filters render as removable chips (`severity: critical ×`). "Clear all" link at right. Removing a chip updates the query and re-fetches.
- **Status filter** — dropdown (All / Open / Acknowledged / Resolved / False positive / Accepted risk), defaults to Open.
- **Sort** — dropdown (Risk descending / Severity / Newest).
- **Issue rows** — gradient card style:
  - Left 3px accent stripe colored by severity
  - Line 1: severity badge + title + status pill
  - Line 2: issue ref + rule name + detection count + time ago
  - Right: risk score (large, severity-colored)
  - Click → opens Issue detail drawer

### API routes added

| Route | Method | Purpose |
|-------|--------|---------|
| `/api/t/<target>/issues` | GET | List issues with filters (`severity`, `status`, `sort`, `rule`) |
| `/api/t/<target>/issues/<ref>` | GET | Single issue detail (merged compute + state) |
| `/api/t/<target>/issues/<ref>/status` | POST | Update issue status (requires note for false_positive/accepted_risk) |

---

## Phase 3 — Issues Engine (correlation + lifecycle)

### What was built

This is the *backend* of Phases 0–2 — documented under Phase 0 above since the engine and rules were built together with the foundations. The key deliverable here is the **correlate hook** wired into the production pipeline:

- `_run_correlate_for_target(scan_id)` — orchestrates the full flow: build entities → run rules → merge state (INV-2) → diff revisions → append events
- **Auto-correlate** hooked into `_ai_watcher_loop` (same place as auto-summarize and Drive sync) — runs automatically when a scan completes
- `/internal/correlate` endpoint — manual trigger for the pipeline hook

### Dedup + auto-resolve lifecycle (verified)

1. First scan → 52 issues created, 52 events emitted
2. Same scan re-correlated → `detections` incremented, no duplicates (INV-1)
3. False-positive mark → survives recompute (INV-2), detections still increments
4. Evidence disappears → `status=resolved`, history `auto_resolved`
5. Evidence reappears → `status=open`, history `reopened` (tombstone reattach)
6. Re-run pipeline → no duplicate events in `events.jsonl` (idempotent append)

---

## Phase 4 — Timeline

### What was built

**Timeline view** (`view-timeline`) — chronological event stream:
- **Diff summary strip** at top — chips counting events by kind (`+4 subs`, `2 issues created`, `1 auto-resolved`), each colored by semantic meaning
- **Event rows** — each row has:
  - Kind icon (colored: new=teal, gone=slate, risk=rose, cert=amber, resolved=green)
  - Description with entity labels (clickable → entity drawer)
  - Revision tag
- **Event kinds:** `new_subdomain`, `subdomain_gone`, `new_ip`, `ip_gone`, `port_opened`, `port_closed`, `service_changed`, `new_vuln_match`, `issue_created`, `issue_auto_resolved`, `issue_reopened`, `issue_status_changed`

**Timeline nav item** added to sidebar (between Graph and AI).

### API route

| Route | Method | Purpose |
|-------|--------|---------|
| `/api/t/<target>/timeline` | GET | Events list + diff summary (filter by `kind`, `limit`) |
| `/api/t/<target>/field-coverage` | GET | Phase-0 audit results |

---

## Navigation changes

The sidebar now has **Issues** as the first item (default landing), with Timeline added between Graph and AI:

| Order | Nav item | View |
|-------|----------|------|
| 1 | **Issues** (new, default) | Correlated findings |
| 2 | Overview | Summary stats |
| 3 | Assets | Host inventory |
| 4 | Vulns | Raw vulnerabilities |
| 5 | CVEs | CVE details |
| 6 | API | API security |
| 7 | Cloud | Cloud exposure |
| 8 | Ports | Port scan |
| 9 | Dirs | Directory discovery |
| 10 | Changes | Scan comparison |
| 11 | Pipeline | Scan orchestration |
| 12 | Graph | WebGL relationship graph |
| 13 | **Timeline** (new) | Event stream |
| 14 | AI | AI analyst |

---

## Files created/modified

### New files
| File | Purpose | Lines |
|------|---------|-------|
| `kaiju_entities.py` | Entity index engine (INV-1) | ~230 |
| `kaiju_issues.py` | Correlation engine + state + timeline (INV-2) | ~530 |
| `KAIJU-EASM-Correlation-UX-Spec-v1.1.md` | Right-sized spec for the real stack | ~280 |
| `CHANGES.md` | This file | — |

### Modified files
| File | Changes |
|------|---------|
| `dashboard.py` | +2 imports, +13 correlation API routes, +1 correlate helper, +1 auto-correlate hook in watcher |
| `templates/dashboard.html` | +Issues nav item, +Timeline nav item, +Issues view section, +Timeline view section, +Entity drawer HTML, +~80 lines CSS (issues, drawer, timeline, evidence chain, filter chips), +~350 lines JS (issues lens, entity drawer, issue detail, timeline, status change) |
| `.gitignore` | +`/state/` (sacred), +`scans/*/.derived/` (regenerable cache) |

### Runtime directories created
| Path | Purpose | Retention |
|------|---------|-----------|
| `state/<target>/` | Issues state + timeline events | **EXEMPT** — never deleted by retention |
| `scans/<id>/.derived/` | Entity index + audit cache | Regenerable — safe to delete |

---

## What's NOT built (deferred per v1.1 spec)

- **Phase 5 — Investigations** (pin board, markdown export) — deferred to later
- **Hash router** (`#/issues?severity=critical&drawer=host:8f3a`) — the URL-is-state principle is architecturally prepared (all state is in JS variables, all views are re-renderable from state) but the actual hash-router wiring is not yet implemented. Currently nav clicks switch views; URL doesn't persist view state.
- **Deep-linked Overview stats** — Overview stat blocks are not yet wired as links to filtered Issues/Vulns views
- **Cross-lens filter carry** — filters don't persist across lens switches
- **Assignees, bulk actions, telemetry** — cut per v1.1 spec (single-analyst tool)
- **PDF export** — markdown-only per v1.1 spec decision
- **❓ rules** (subdomain-takeover, expired-cert, KEV, EOL-software) — blocked on pipeline data enrichment

---

## Invariants preserved

| Invariant | Status | Evidence |
|-----------|--------|----------|
| INV-1 (stable refs) | Verified | Recompute test passes; refs derived from natural keys only |
| INV-2 (compute/state merge) | Verified | false_positive survives recompute; orphans tombstoned |
| Atomic writes | Implemented | temp+os.rename+.bak for JSON; dedup-on-append for JSONL |
| State is sacred | Implemented | `state/` is retention-exempt, gitignored, first in Drive sync set |
| Idempotent append | Verified | Re-running correlate produces no duplicate events |
